import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PetTest {

    private Pet pet;

    @BeforeEach
    public void setUp() {
        pet = new Pet("Fluffy", "Cat");
    }

    @Test
    public void testInitialHealth() {
        assertEquals(100, pet.getHealth(), "Initial health should be 100");
    }

    @Test
    public void testInitialHappiness() {
        assertEquals(50, pet.getHappiness(), "Initial happiness should be 50");
    }

    @Test
    public void testFeedPet() {
        int initialFullness = pet.getFullness();
        pet.feed(20);
        assertEquals(initialFullness + 20, pet.getFullness(), "Fullness should increase by the food value");
    }

    @Test
    public void testFeedPetMaxFullness() {
        pet.setFullness(90);
        pet.feed(20);
        assertEquals(100, pet.getFullness(), "Fullness should not exceed 100");
    }

    @Test
    public void testHealthDecay() throws InterruptedException {
        pet.updateStats(); // Update stats manually to simulate time passing
        int initialHealth = pet.getHealth();
        Thread.sleep(10000); // Wait for the health decay to happen
        assertTrue(pet.getHealth() < initialHealth, "Health should decay over time");
    }

    @Test
    public void testPetStateHappy() {
        pet.setHealth(80);
        pet.setFullness(80);
        pet.setSleep(80);
        pet.checkState();
        assertEquals(Pet.PetState.HAPPY, pet.getState(), "Pet state should be HAPPY if health, fullness, and sleep are all high");
    }

    @Test
    public void testPetStateCritical() {
        pet.setHealth(0);
        pet.checkState();
        assertEquals(Pet.PetState.CRITICAL, pet.getState(), "Pet state should be CRITICAL if health is 0");
    }

    @Test
    public void testPlayWithPet() {
        int initialHappiness = pet.getHappiness();
        pet.play();
        assertTrue(pet.getHappiness() > initialHappiness, "Happiness should increase after playing");
        assertTrue(pet.getSleep() < 50, "Sleep should decrease after playing");
        assertTrue(pet.getFullness() < 50, "Fullness should decrease after playing");
    }

    @Test
    public void testGoToBed() {
        pet.setSleep(40);
        pet.goToBed();
        assertEquals(100, pet.getSleep(), "Sleep should increase to 100 after going to bed");
    }

    @Test
    public void testExercise() {
        int initialHealth = pet.getHealth();
        pet.exercise();
        assertTrue(pet.getHealth() > initialHealth, "Health should increase after exercise");
        assertTrue(pet.getSleep() < 50, "Sleep should decrease after exercise");
        assertTrue(pet.getFullness() < 50, "Fullness should decrease after exercise");
    }

    @Test
    public void testRevive() {
        pet.setHealth(0); // Simulate death
        pet.revive();
        assertTrue(pet.isAlive(), "Pet should be revived");
        assertEquals(50, pet.getHealth(), "Pet's health should be reset to 50 after revival");
    }

    @Test
    public void testTakeToVet() {
        int initialHealth = pet.getHealth();
        pet.takeToVet();
        assertEquals(initialHealth, pet.getHealth(), "Health should not change after a vet visit, but happiness should decrease");
    }
}
