package com.cs2212.petdemo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StatisticsTest {

    private ParentalControls parentalControls;
    private Statistics statistics;
    private Map<String, Integer> mockStats;

    @BeforeEach
    public void setUp() {
        // Set up mock parental controls and statistics
        parentalControls = mock(ParentalControls.class);
        mockStats = new HashMap<>();
        mockStats.put("totalPlayTime", 10);
        mockStats.put("averagePlayTime", 5);

        when(parentalControls.getStatistics()).thenReturn(mockStats);

        // Create Statistics instance with mocked ParentalControls
        statistics = new Statistics(parentalControls);
    }

    @Test
    public void testStatisticsInitialization() {
        // Test if Statistics initializes properly and gets statistics from ParentalControls
        assertNotNull(statistics, "Statistics should not be null.");
        assertEquals(mockStats, statistics.getStats(), "Statistics should match the expected mock stats.");
    }

    @Test
    public void testDisplayStatistics() {
        // Test if statistics are displayed correctly on the labels
        statistics.displayStatistics();

        assertEquals("Total Play Time: 10 hours", statistics.jLabel4.getText(), "Total Play Time should display correctly.");
        assertEquals("Average Play Time: 5 hours", statistics.jLabel5.getText(), "Average Play Time should display correctly.");
    }

    @Test
    public void testSetStats() {
        // Test if setStats works as expected
        Map<String, Integer> newStats = new HashMap<>();
        newStats.put("totalPlayTime", 20);
        newStats.put("averagePlayTime", 10);
        
        statistics.setStats(newStats);

        assertEquals(newStats, statistics.getStats(), "The stats should be updated with the new values.");
    }

    @Test
    public void testBackButtonAction() {
        // Mock the action that happens when the back button is clicked
        settings settingsScreen = mock(settings.class);
        statistics.backActionPerformed(null);  // Simulate button click

        // Verify that the settings screen is shown after the button is clicked
        verify(settingsScreen).setVisible(true);
    }

    @Test
    public void testMainMethod() {
        // Test if the main method runs correctly
        assertDoesNotThrow(() -> Statistics.main(new String[]{}), "Main method should not throw any exceptions.");
    }

    @Test
    public void testUIComponentVisibility() {
        // Test if the components are visible when the frame is shown
        statistics.setVisible(true);

        assertTrue(statistics.jLabel1.isVisible(), "Label 1 (Parental Statistics) should be visible.");
        assertTrue(statistics.jLabel2.isVisible(), "Label 2 (Total Play Time) should be visible.");
        assertTrue(statistics.jLabel3.isVisible(), "Label 3 (Average Play Time) should be visible.");
        assertTrue(statistics.jLabel4.isVisible(), "Label 4 (Total Play Time value) should be visible.");
        assertTrue(statistics.jLabel5.isVisible(), "Label 5 (Average Play Time value) should be visible.");
        assertTrue(statistics.back.isVisible(), "Back button should be visible.");
    }
}
