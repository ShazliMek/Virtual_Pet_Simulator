/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cs2212.petdemo;

/**
 * This class is for the food inventory.
 * 
 * @author shazlimekrani
 */
public class FoodInventory extends InventoryItem {
    // Hardcoded effect values for foods
    public static final int FOOD1_VALUE = 45;
    public static final int FOOD2_VALUE = 30;
    public static final int FOOD3_VALUE = 20;
    public static final int FOOD4_VALUE = 15;

    /**
     * This method is the constructor for the FoodInventory class
     * 
     * @param name
     * @param quantity
     * @param type
     * @param effectValue
     */
    public FoodInventory(String name, int quantity, String type, int effectValue) {
    super(name, quantity, type,effectValue);
    }

    /**
     * This method is for creating a predefined food 1.
     * 
     * @return FoodInventory
     */
    public static FoodInventory createFood1() {
        return new FoodInventory("Food1",1 ,"food", FOOD1_VALUE);
    }

    /**
     * This method is for creating a predefined food 2.
     * 
     * @return FoodInventory
     */
    public static FoodInventory createFood2() {
        return new FoodInventory("Food2",1,"food", FOOD2_VALUE);
    }

    /**
     * This method is for creating a predefined food 3.
     * 
     * @return FoodInventory
     */
    public static FoodInventory createFood3() {
        return new FoodInventory("Food3",1,"food", FOOD3_VALUE);
    }

    /**
     * This method is for creating a predefined food 4.
     * 
     * @return FoodInventory
     */
    public static FoodInventory createFood4() {
        return new FoodInventory("Food4",1,"food", FOOD4_VALUE);
    }

    /**
     * This method is for determining the effect applied on the pet.
     * 
     * @param pet
     */
    @Override
    public void applyEffect(Pet pet) {
        int newFullness = pet.getFullness() + getEffectValue();
        pet.setFullness(Math.min(newFullness, pet.getMaxFullness())); // Cap at max fullness
        System.out.println(pet.getName() + "'s fullness increased to: " + pet.getFullness());
    } 
}
