package com.cs2212.petdemo;

import java.io.*;
import java.nio.file.Paths;
import java.util.*;
/**
 * This class is for the functions of the CSV file like saving data and loading data.
 * 
 * @author Alishba Asif
 */
public class CSVUtility {

 public static final String SAVE_FOLDER = "./saves/";
 
    /**
     * This method is for saving data to a CSV file.
     * 
     * @param filePath
     * @param data
     * @throws IOException
     */
    public static void saveToCSV(String filePath, List<String[]> data) throws IOException {
        File file = new File(filePath);
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            for (String[] line : data) {
                writer.println(String.join(",", line));
            }
        }
    }
    /**
     * This method is for loading data from a CSV file.
     * 
     * @param filePath
     * @return data
     * @throws IOException
     */
    public static List<String[]> loadFromCSV(String filePath) throws IOException {
        List<String[]> data = new ArrayList<>();
        File file = new File(filePath);
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                data.add(line.split(","));
            }
        }
        return data;
    }  
}
