package com.cs2212.petdemo;

import java.util.*;
import java.io.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 * This is the class for the parental controls, that will only be accessible to the parents.
 * 
 * @author Harnoor Aujla
 */
public class ParentalControls {
    private static final String USERNAME = "parent";
    private static final String PASSWORD = "1234";
    private static final String PLAYTIME_LIMITS_FILE = "playtime_limits.txt";
    private static final String PET_STATES_FILE = "./saves/pet_states.csv";

    private LocalTime startAllowedTime = LocalTime.of(9, 0); // Default: 9:00 AM
    private LocalTime endAllowedTime = LocalTime.of(21, 0); // Default: 9:00 PM
    private final Map<Integer, Integer> petHealth = new HashMap<>(); // Pet health values
    private final Map<Integer, Boolean> petStates = new HashMap<>(); // Pet states: true = alive, false = dead

    /**
     * This is the constructor for the class ParentalControls.
     */
    public ParentalControls() {
        loadPlaytimeLimits();
        loadPetStates();
        startHealthDecay();
        loadPlaytimeLimits();
    }
    
    /**
     * This method is for loading the playtime limits.
     */
    private void loadPlaytimeLimits() {
        File file = new File(PLAYTIME_LIMITS_FILE);

        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                this.startAllowedTime = LocalTime.parse(reader.readLine());
                this.endAllowedTime = LocalTime.parse(reader.readLine());
            } catch (IOException | NullPointerException e) {
                System.err.println("Error loading playtime limits. Using default values.");
                this.startAllowedTime = LocalTime.of(9, 0);
                this.endAllowedTime = LocalTime.of(21, 0);
            }
        } else {
            System.out.println("No saved playtime limits found. Using default values.");
            this.startAllowedTime = LocalTime.of(9, 0);
            this.endAllowedTime = LocalTime.of(21, 0);
        }

        // Debugging output
        System.out.println("Loaded Start Allowed Time: " + this.startAllowedTime);
        System.out.println("Loaded End Allowed Time: " + this.endAllowedTime);
    }

    /**
     * This method is for validating the login information.
     * 
     * @param inputUsername
     * @param inputPassword
     * @return boolean
     */
    public boolean validateLogin(String inputUsername, String inputPassword) {
        return USERNAME.equals(inputUsername) && PASSWORD.equals(inputPassword);
    }

    /**
     * This method is setting the playtime limits.
     * 
     * @param start
     * @param end
     */
    public void setPlaytimeLimits(String start, String end) {
        this.startAllowedTime = LocalTime.parse(start);
        this.endAllowedTime = LocalTime.parse(end);
        savePlaytimeLimits();
    }

    /**
     * This method is for getting the playtime limits.
     * 
     * @return String[]
     */
    public String[] getPlaytimeLimits() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a");
        return new String[]{
            startAllowedTime.format(formatter),
            endAllowedTime.format(formatter)
        };
    }
    
    /**
     * This method is for checking if the current time is within the range of the allowed time.
     * 
     * @return boolean
     */
    public boolean isWithinAllowedTime() {
        LocalTime now = LocalTime.now();
        System.out.println("Current Time: " + now); // Debug statement
        System.out.println("Allowed Range: " + startAllowedTime + " - " + endAllowedTime); // Debug statement
        return now.isAfter(startAllowedTime) && now.isBefore(endAllowedTime);
    }

    /**
     * This method is for enforcing the playtime restrictions.
     */
    public void enforcePlaytimeRestrictions() {
        if (!isWithinAllowedTime()) {
            JOptionPane.showMessageDialog(null, "Playtime is not allowed at this time. Please try again later.", "Access Restricted", JOptionPane.WARNING_MESSAGE);
            System.exit(0); // End the game or redirect to a restricted screen
        }
    }

    /**
     * This method is for reviving the pet.
     * 
     * @param index
     * @return boolean
     */
    public boolean revivePet(int index) {
        if (petStates.containsKey(index) && !petStates.get(index)) {
            petStates.put(index, true); // Set the pet as alive
            petHealth.put(index, 100); // Reset health to 100
            savePetStates();
            return true;
        }
        return false; // Pet is already alive
    }

    /**
     * This method is for getting the pet states.
     * 
     * @return petStates
     */
    public Map<Integer, Boolean> getPetStates() {
        return petStates;
    }

    /**
     * This method is for getting the pet's health.
     * 
     * @return petHealth
     */
    public Map<Integer, Integer> getPetHealth() {
        return petHealth;
    }
    
    /**
     * This method is for getting the start allowed time.
     * 
     * @return startAllowedTime
     */
    public LocalTime getStartAllowedTime() {
        return startAllowedTime;
    }

    /**
     * This method is for getting the end allowed time.
     * 
     * @return endAllowedTime
     */
    public LocalTime getEndAllowedTime() {
        return endAllowedTime;
    }

    /**
     * This method is for automatizing the pet's health decay.
     */
    private void startHealthDecay() {
        Timer timer = new Timer(true); // Create a background timer
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                for (Map.Entry<Integer, Integer> entry : petHealth.entrySet()) {
                    int petIndex = entry.getKey();
                    int health = entry.getValue();

                    // Reduce health by 10 every 10 seconds if the pet is alive
                    if (petStates.getOrDefault(petIndex, false)) {
                        health -= 10;
                        if (health <= 0) {
                            health = 0;
                            petStates.put(petIndex, false); // Pet is now dead
                        }
                        petHealth.put(petIndex, health);
                    }
                }
                savePetStates(); // Save updated states to the CSV file
            }
        }, 0, 10000); // Execute every 10 seconds
    }

    /**
     * This method is for saving the pet states and health to a CSV file.
     */
    private void savePetStates() {
        List<String[]> data = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : petHealth.entrySet()) {
            int petIndex = entry.getKey();
            int health = entry.getValue();
            boolean isAlive = petStates.getOrDefault(petIndex, false);
            data.add(new String[]{String.valueOf(petIndex), String.valueOf(health), String.valueOf(isAlive)});
        }
        try {
            CSVUtility.saveToCSV(PET_STATES_FILE, data);
        } catch (IOException e) {
            System.err.println("Error saving pet states: " + e.getMessage());
        }
    }

    /**
     * This method is for getting the statistics.
     * 
     * @return stats
     */
    public Map<String, Integer> getStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        // Calculate total and average playtime dynamically
        int totalPlayTime = 1; // Placeholder; replace with actual calculation
        int averagePlayTime = totalPlayTime / Math.max(petStates.size(), 1);

        stats.put("totalPlayTime", totalPlayTime);
        stats.put("averagePlayTime", averagePlayTime);
        return stats;
    }

    /**
     * This method if for loading pet states and health from a CSV file.
     */
    private void loadPetStates() {
        try {
            List<String[]> data = CSVUtility.loadFromCSV(PET_STATES_FILE);
            for (String[] line : data) {
                int petIndex = Integer.parseInt(line[0]);
                int health = Integer.parseInt(line[1]);
                boolean isAlive = Boolean.parseBoolean(line[2]);
                petHealth.put(petIndex, health);
                petStates.put(petIndex, isAlive);
            }
        } catch (IOException e) {
            System.err.println("Error loading pet states: " + e.getMessage());
            initializeDefaultPetStates();
        }
    }

    /**
     * This method is for initializing the defult pet states.
     */
    private void initializeDefaultPetStates() {
        for (int i = 1; i <= 3; i++) { // Default 3 pets
            petHealth.put(i, 100);
            petStates.put(i, true);
        }
    }

    /**
     * This method is for saving the playtime limits.
     */
    private void savePlaytimeLimits() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PLAYTIME_LIMITS_FILE))) {
            writer.write(startAllowedTime.toString() + "\n" + endAllowedTime.toString());
        } catch (IOException e) {
            System.err.println("Error saving playtime limits: " + e.getMessage());
        }
    }
}

