/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.cs2212.petdemo;

import java.util.concurrent.ScheduledExecutorService;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * This is the class of the Main Room.
 * 
 * @author shazlimekrani
 */
public class MainRoom extends javax.swing.JFrame {
    private GameState gameState;  // The current game state
    private int slotIndex;       // The save slot index
    private GameTimer gameTimer; // Timer for managing periodic updates
    private ScheduledExecutorService inventoryUpdater; // Scheduler for inventory updates


    /**     
     * This is the constructor of the class Main Room that creates new form MainRoom 
     * 
     * @param gameState
     * @param slotIndex
     */
    public MainRoom(GameState gameState, int slotIndex) {
        this.gameState = gameState;
        this.slotIndex = slotIndex;
        initComponents();
        initializeGameTimer(); // Start updating inventory every 10 seconds
        updateUIWithGameState(); // Initialize UI with current game data
        
        updatePetImage("default");
    }
    
    /**
     * This method initializes the GameTimer with the current pet.
     */
    private void initializeGameTimer() {
        if (gameState != null && gameState.getPet() != null && gameState.getInventory() != null) {
            gameTimer = new GameTimer(gameState.getPet(), gameState.getInventory());
            gameTimer.start(); // Start the timer
        } else {
            System.out.println("GameState, Pet, or Inventory is null. Timer not started.");
        }
    } 
    
    /** 
     * This method is for setting the game state.
     * 
     * @param gameState
     */
    public void setGameState(GameState gameState) {
        this.gameState = gameState;
        updateUIWithGameState();
    }

    /**
     * This method is for getting the game state.
     * 
     * @return gameState
     */
    public GameState getGameState() {
        return gameState;
    }
    

    /**
     * This method updates the UI elements based on the GameState.
     */
    private void updateUIWithGameState() {
    if (gameState != null && gameState.getPet() != null) {
        Pet pet = gameState.getPet();

        HealthBar.setValue(pet.getHealth());
        SleepBar.setValue(pet.getSleep());
        FullnessBar.setValue(pet.getFullness());
        HappinessBar.setValue(pet.getHappiness());

        jLabel2.setText("Health: " + pet.getHealth());
        jLabel3.setText("Sleep: " + pet.getSleep());
        jLabel4.setText("Fullness: " + pet.getFullness());
        jLabel5.setText("Happiness: " + pet.getHappiness());
        jLabel6.setText("Level: " + "1"); // Example level; modify as needed

        System.out.println("UI updated with Happiness: " + pet.getHappiness());
    } else {
        System.out.println("GameState or Pet is null. Unable to update UI.");
        }
    if (gameState.getPet() != null) {
            Pet pet = gameState.getPet();
            jLabelStatus.setText(pet.isAlive() ? "Alive" : "Dead");
        }
    }

    /**
     * This method is for updating the pet image.
     * 
     * @param activity
     */
    private void updatePetImage(String activity) {
        String basePath = "src/main/resources/";
        Pet pet = gameState.getPet();
        if (pet == null) {
            System.out.println("No pet selected. Unable to load image.");
            return;
        }
        
    
        if (!pet.isAlive()) {
            // Set image to a dead pet if the pet is dead
            String imagePath = basePath + pet.getName() + "/"
                    + pet.getName() + "-Dead.png";
            try {
                petImageLabel.setIcon(new javax.swing.ImageIcon(imagePath));
            } catch (Exception e) {
                System.out.println("Error loading image: " + e.getMessage());
            }
            return; // Return early since we don't want to update the image for other actions
        }

        String petName = pet.getName(); // Get the selected pet's name
        String imagePath = basePath + petName + "/";

        // Determine the image to load based on the activity
        switch (activity) {
            case "Feed":
                imagePath += petName + "-Normal-Up.png";
                break;
            case "Play":
                imagePath += petName + "-Interact.png";
                break;
            case "Sleep":
                imagePath += petName + "-Sleeping.png";
                break;
            case "Exercise":
                imagePath += petName + "-Hungry.png";
                break;
            case "Vet":
                imagePath += petName + "-Angry.png";
                break;
            case "default":
            default:
                imagePath += petName + "-Normal-Down.png";
                break;
        }

        // Load the image
        try {
            petImageLabel.setIcon(new javax.swing.ImageIcon(imagePath));
        } catch (Exception e) {
            System.out.println("Error loading image: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents

    /**
     * This method is for initializing components.
     */
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        jFrame3 = new javax.swing.JFrame();
        jFrame4 = new javax.swing.JFrame();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jToggleButton7 = new javax.swing.JToggleButton();
        petImageLabel = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        HealthBar = new javax.swing.JProgressBar();
        FullnessBar = new javax.swing.JProgressBar();
        SleepBar = new javax.swing.JProgressBar();
        HappinessBar = new javax.swing.JProgressBar();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Feed = new javax.swing.JToggleButton();
        Gift = new javax.swing.JToggleButton();
        Exercise = new javax.swing.JToggleButton();
        Vet = new javax.swing.JToggleButton();
        Inventory = new javax.swing.JToggleButton();
        save = new javax.swing.JButton();
        Play = new javax.swing.JButton();
        sleep = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabelStatus = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame3Layout.setVerticalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame4Layout = new javax.swing.GroupLayout(jFrame4.getContentPane());
        jFrame4.getContentPane().setLayout(jFrame4Layout);
        jFrame4Layout.setHorizontalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame4Layout.setVerticalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jMenuItem1.setText("jMenuItem1");

        jMenu1.setText("jMenu1");

        jToggleButton7.setText("jToggleButton4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        petImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel2.setText("Health");

        jLabel3.setText("Sleep");

        jLabel4.setText("Fullness");

        jLabel5.setText("Happiness");

        jLabel6.setText("Level X");

        Feed.setText("Feed");
        Feed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedActionPerformed(evt);
            }
        });

        Gift.setText("Gift");
        Gift.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GiftActionPerformed(evt);
            }
        });

        Exercise.setText("Exercise");
        Exercise.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExerciseActionPerformed(evt);
            }
        });

        Vet.setText("Vet");
        Vet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VetActionPerformed(evt);
            }
        });

        Inventory.setText("Inventory");
        Inventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InventoryActionPerformed(evt);
            }
        });

        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        Play.setText("Play");
        Play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayActionPerformed(evt);
            }
        });

        sleep.setText("Sleep");
        sleep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sleepActionPerformed(evt);
            }
        });

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

        jLabelStatus.setText("jLabel7");
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3)
                        .addComponent(jLabel4)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabelStatus))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 327, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(save)
                            .addComponent(Exit))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(HealthBar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SleepBar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FullnessBar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(HappinessBar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Play)
                                .addGap(18, 18, 18)
                                .addComponent(Exercise, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Vet)
                                .addGap(18, 18, 18)
                                .addComponent(Inventory)
                                .addGap(18, 18, 18)
                                .addComponent(sleep))
                            .addComponent(petImageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(Feed, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Gift, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(HealthBar, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(SleepBar, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FullnessBar, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(HappinessBar, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabelStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(petImageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(save)
                        .addGap(18, 18, 18)
                        .addComponent(Exit)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Feed)
                    .addComponent(Gift)
                    .addComponent(Exercise)
                    .addComponent(Vet)
                    .addComponent(Inventory)
                    .addComponent(Play)
                    .addComponent(sleep))
                .addGap(101, 101, 101))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * This method is for when the feeding action id preformend.
     * 
     * @param evt
     */
    private void FeedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedActionPerformed
        if (gameState != null) {
        Inventory inventory = gameState.getInventory();
        if (inventory == null) {
            JOptionPane.showMessageDialog(this, "Inventory is null!");
            return;
        }

        // Food options available in the inventory
        String[] foodItems = {"Pizza", "Burger", "CottonCandy", "Drink"};

        // Display a dialog for food selection
        String selectedFood = (String) JOptionPane.showInputDialog(
                this,
                "Choose a food item to feed your pet:",
                "Feed Your Pet",
                JOptionPane.PLAIN_MESSAGE,
                null,
                foodItems,
                foodItems[0]);

        if (selectedFood != null) {
            InventoryItem foodItem = inventory.getItemByName(selectedFood);
            if (foodItem != null && foodItem.getQuantity() > 0) {
                gameState.getPet().feed(foodItem.getEffectValue()); // Apply the food's effect
                foodItem.decrementQuantity(); // Decrease food quantity
                updatePetImage("Feed"); // Update the pet image to reflect feeding
                updateUIWithGameState(); // Refresh the UI

                // Show confirmation dialog
                JOptionPane.showMessageDialog(
                        this,
                        "Your pet has been fed with " + selectedFood + "!",
                        "Feeding Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(this, "You don't have any " + selectedFood + " left!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No food selected.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "GameState is null. Cannot feed the pet.");
    }
    }//GEN-LAST:event_FeedActionPerformed

    /**
     * This method is for when inventory action is preformed.
     * 
     * @param evt
     */
    private void InventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InventoryActionPerformed
        // TODO add your handling code here:
        new InventoryScreen(gameState, slotIndex).setVisible(true);
    }//GEN-LAST:event_InventoryActionPerformed

    /**
     * This method is for when save action is preformed.
     * 
     * @param evt
     */
    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:                                     
        if (gameState != null) {
            String saveFile = "saves/slot" + (slotIndex + 1) + ".csv";
            try {
                GameSaveManager manager = new GameSaveManager();
                manager.saveGame(gameState, saveFile);
                JOptionPane.showMessageDialog(this, "Game saved successfully in Slot " + (slotIndex + 1));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Failed to save game: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "GameState is null. Cannot save.");
        }
    }//GEN-LAST:event_saveActionPerformed

    /**
     * This method is for when gift action is preformed.
     * 
     * @param evt
     */
    private void GiftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GiftActionPerformed
        // TODO add your handling code here:
        if (gameState != null) {
            Inventory inventory = gameState.getInventory();
            String[] giftItems = {"Gift1", "Gift2", "Ears", "PartyHat"};

            for (String gift : giftItems) {
                if (inventory.useItemByName(gift)) {
                    gameState.getPet().play(); // Assume play action increases happiness
                    updatePetImage("Play");
                    updateUIWithGameState();
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "No gift items left to give to the pet!");
        }
    }//GEN-LAST:event_GiftActionPerformed

    /**
     * This method is for when play action is preformed.
     * 
     * @param evt
     */
    private void PlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayActionPerformed
        // TODO add your handling code here:
        if (gameState != null) {
        gameState.getPet().play(); // Example play action
        updatePetImage("Play"); // Update pet image
        updateUIWithGameState(); // Refresh UI
    }
    }//GEN-LAST:event_PlayActionPerformed

    /**
     * This method is for when sleep action is preformed.
     * 
     * @param evt
     */
    private void sleepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sleepActionPerformed
        // TODO add your handling code here:
        if (gameState != null) {
        gameState.getPet().goToBed(); // Example sleep action
        updatePetImage("Sleep"); // Update pet image
        updateUIWithGameState(); // Refresh UI
    }
    }//GEN-LAST:event_sleepActionPerformed

    /**
     * This method is for when excersise action is preformed.
     * 
     * @param evt
     */
    private void ExerciseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExerciseActionPerformed
        // TODO add your handling code here:
        if (gameState != null) {
            gameState.getPet().exercise(); // Example exercise action
            updatePetImage("Exercise"); // Update pet image
            updateUIWithGameState(); // Refresh UI
        }
    }//GEN-LAST:event_ExerciseActionPerformed

    /**
     * This method is for when vet action is preformed.
     * 
     * @param evt
     */
    private void VetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VetActionPerformed
        // TODO add your handling code here:
        if (gameState != null) {
            gameState.getPet().takeToVet(); // Example vet action
            updatePetImage("Vet"); // Update pet image
            updateUIWithGameState(); // Refresh UI
        }
    }//GEN-LAST:event_VetActionPerformed

    /**
     * This method is for when exit action is preformed.
     * 
     * @param evt
     */
    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        // TODO add your handling code here:
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ExitActionPerformed

    /**
     * This is the main method for the class MainRoom.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pet pet = new Pet("Buddy", "Dog");
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 0;
        int slotIndex = 0;
        GameState gameState = new GameState(pet, inventory, parentalControls, score, slotIndex);

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainRoom(gameState, 1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton Exercise;
    private javax.swing.JButton Exit;
    private javax.swing.JToggleButton Feed;
    private javax.swing.JProgressBar FullnessBar;
    private javax.swing.JToggleButton Gift;
    private javax.swing.JProgressBar HappinessBar;
    private javax.swing.JProgressBar HealthBar;
    private javax.swing.JToggleButton Inventory;
    private javax.swing.JButton Play;
    private javax.swing.JProgressBar SleepBar;
    private javax.swing.JToggleButton Vet;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JFrame jFrame4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelStatus;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JToggleButton jToggleButton7;
    private javax.swing.JLabel petImageLabel;
    private javax.swing.JButton save;
    private javax.swing.JButton sleep;
    // End of variables declaration//GEN-END:variables
}
