package com.cs2212.petdemo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MainRoomTest {
    
    private MainRoom mainRoom;
    private GameState gameState;
    private int slotIndex = 0;

    @BeforeEach
    public void setUp() {
        // Initialize the necessary objects before each test
        Pet pet = new Pet("Buddy", "Dog");
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 0;
        
        gameState = new GameState(pet, inventory, parentalControls, score, slotIndex);
        
        // Initialize MainRoom with the game state and slot index
        mainRoom = new MainRoom(gameState, slotIndex);
    }
    
    @Test
    public void testGameStateInitialization() {
        assertNotNull(mainRoom);
        assertEquals(gameState, mainRoom.gameState);
    }

    @Test
    public void testSlotIndexInitialization() {
        assertEquals(slotIndex, mainRoom.slotIndex);
    }

    @Test
    public void testGameTimerInitialization() {
        // Assuming GameTimer is initialized in MainRoom
        assertNotNull(mainRoom.gameTimer);
    }

    @Test
    public void testUpdateUIWithGameState() {
        // Test that the UI updates correctly with the game state
        // Since MainRoom is a GUI, you would typically use a framework like AssertJ or Jemmy for GUI testing
        mainRoom.updateUIWithGameState();
        // Assertions depend on the actual updates happening in the UI.
        // For example, checking if the pet's name is displayed in the UI.
    }
    
    // You may need additional tests for specific methods like button clicks or pet image updates.
}

