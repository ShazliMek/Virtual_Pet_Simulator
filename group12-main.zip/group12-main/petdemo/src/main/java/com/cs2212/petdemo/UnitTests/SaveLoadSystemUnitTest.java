package com.cs2212.petdemo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class SaveLoadSystemTest {

    private static final String GAME_FILE = "testGameState.ser";
    private static final String STATS_FILE = "testStatistics.ser";

    private GameState gameState;
    private Statistics statistics;

    @BeforeEach
    public void setUp() {
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 0;
        int slotIndex = 0;
        gameState = new GameState(null, inventory, parentalControls, score, slotIndex);
        statistics = new Statistics(parentalControls);
    }

    @Test
    public void testSaveGame() {
        // Save the game state
        SaveLoadSystem.saveGame(gameState, GAME_FILE);

        // Check if the file exists
        File gameFile = new File(GAME_FILE);
        assertTrue(gameFile.exists(), "Game file should exist after saving.");
    }

    @Test
    public void testLoadGame() {
        // First, save the game state
        SaveLoadSystem.saveGame(gameState, GAME_FILE);

        // Now load the game state
        GameState loadedGameState = SaveLoadSystem.loadGame(GAME_FILE);

        // Assert that the loaded game state is not null
        assertNotNull(loadedGameState, "Loaded game state should not be null.");

        // Optionally, check if some properties of the loaded state match
        assertEquals(gameState.getSlotIndex(), loadedGameState.getSlotIndex(),
                "Slot index should match after loading.");
    }

    @Test
    public void testSaveStatistics() {
        // Save statistics
        SaveLoadSystem saveLoadSystem = new SaveLoadSystem();
        saveLoadSystem.saveStatistics(statistics, STATS_FILE);

        // Check if the statistics file exists
        File statsFile = new File(STATS_FILE);
        assertTrue(statsFile.exists(), "Statistics file should exist after saving.");
    }

    @Test
    public void testLoadStatistics() {
        // Save the statistics
        SaveLoadSystem saveLoadSystem = new SaveLoadSystem();
        saveLoadSystem.saveStatistics(statistics, STATS_FILE);

        // Load the statistics
        Statistics loadedStats = saveLoadSystem.loadStatistics(STATS_FILE);

        // Assert that the loaded statistics are not null
        assertNotNull(loadedStats, "Loaded statistics should not be null.");

        // Optionally, check if some properties of the statistics match
        assertNotNull(loadedStats.getParentalControls(), "ParentalControls should not be null in loaded statistics.");
    }

    @Test
    public void testLoadGameWithInvalidFile() {
        // Try to load a game state from a non-existent file
        GameState loadedGameState = SaveLoadSystem.loadGame("invalidFile.ser");

        // Assert that the loaded game state is null
        assertNull(loadedGameState, "Game state should be null when loading from a non-existent file.");
    }

    @Test
    public void testLoadStatisticsWithInvalidFile() {
        // Try to load statistics from a non-existent file
        SaveLoadSystem saveLoadSystem = new SaveLoadSystem();
        Statistics loadedStats = saveLoadSystem.loadStatistics("invalidStatsFile.ser");

        // Assert that the loaded statistics are not null and a default object is returned
        assertNotNull(loadedStats, "Loaded statistics should not be null.");
        assertNotNull(loadedStats.getParentalControls(), "ParentalControls should not be null in loaded statistics.");
    }

    @Test
    public void testSaveAndLoadGameConsistency() {
        // Save the game state
        SaveLoadSystem.saveGame(gameState, GAME_FILE);

        // Load the game state
        GameState loadedGameState = SaveLoadSystem.loadGame(GAME_FILE);

        // Assert that the loaded game state is the same as the original
        assertEquals(gameState.getSlotIndex(), loadedGameState.getSlotIndex(),
                "Slot index should match after saving and loading.");
    }

    @Test
    public void testSaveAndLoadStatisticsConsistency() {
        // Save statistics
        SaveLoadSystem saveLoadSystem = new SaveLoadSystem();
        saveLoadSystem.saveStatistics(statistics, STATS_FILE);

        // Load statistics
        Statistics loadedStats = saveLoadSystem.loadStatistics(STATS_FILE);

        // Assert that the loaded statistics are the same as the original
        assertEquals(statistics.getParentalControls(), loadedStats.getParentalControls(),
                "ParentalControls should match after saving and loading.");
    }

    // Cleanup test files after tests
    @AfterEach
    public void tearDown() {
        new File(GAME_FILE).delete();
        new File(STATS_FILE).delete();
    }
}

