import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class PetSelectionScreenTest {

    private Pet_Selection_Screen petSelectionScreen;
    private GameState gameStateMock;
    private Inventory inventoryMock;
    private ParentalControls parentalControlsMock;

    @BeforeEach
    public void setUp() {
        // Create mocks for the GameState and other dependencies
        inventoryMock = mock(Inventory.class);
        parentalControlsMock = mock(ParentalControls.class);
        gameStateMock = mock(GameState.class);

        // Initialize the Pet_Selection_Screen with mock GameState and a default slot index
        petSelectionScreen = new Pet_Selection_Screen(gameStateMock, 0);
    }

    @Test
    public void testSetAndGetSlotIndex() {
        // Test setting and getting the slot index
        petSelectionScreen.setSlotIndex(2);
        assertEquals(2, petSelectionScreen.getSlotIndex(), "The slot index should be 2.");
    }

    @Test
    public void testSelectPet1() {
        // Call the method to select pet 1
        petSelectionScreen.selectPet1();

        // Verify if the game state has been updated correctly
        verify(gameStateMock, times(1)).setPet(any(Pet.class));
        verify(gameStateMock, times(1)).setSlotIndex(0);

        // Optionally, you could check that the starting room screen is opened (if possible to mock)
        // verify(startingRoomMock, times(1)).setVisible(true);
    }

    @Test
    public void testSelectPet2() {
        // Call the method to select pet 2
        petSelectionScreen.selectPet2();

        // Verify if the game state has been updated correctly
        verify(gameStateMock, times(1)).setPet(any(Pet.class));
        verify(gameStateMock, times(1)).setSlotIndex(1);

        // Optionally, you could check that the starting room screen is opened (if possible to mock)
        // verify(startingRoomMock, times(1)).setVisible(true);
    }

    @Test
    public void testSelectPet3() {
        // Call the method to select pet 3
        petSelectionScreen.selectPet3();

        // Verify if the game state has been updated correctly
        verify(gameStateMock, times(1)).setPet(any(Pet.class));
        verify(gameStateMock, times(1)).setSlotIndex(2);

        // Optionally, you could check that the starting room screen is opened (if possible to mock)
        // verify(startingRoomMock, times(1)).setVisible(true);
    }

    @Test
    public void testProceedToStartingRoom() {
        // Here you can test the interaction with the starting room, but this might require more mocking
        // as the `StartingRoom` class is involved in the `proceedToStartingRoom()` method.
    }
}
