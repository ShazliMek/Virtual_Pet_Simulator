import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

import java.time.LocalTime;
import java.util.Map;

public class ParentalControlsTest {

    private ParentalControls parentalControls;

    @BeforeEach
    public void setUp() {
        parentalControls = new ParentalControls();
    }

    @Test
    public void testValidateLoginSuccess() {
        assertTrue(parentalControls.validateLogin("parent", "1234"), "Login should be successful with correct credentials");
    }

    @Test
    public void testValidateLoginFailure() {
        assertFalse(parentalControls.validateLogin("wrongUser", "wrongPassword"), "Login should fail with incorrect credentials");
    }

    @Test
    public void testSetAndGetPlaytimeLimits() {
        String start = "08:00 AM";
        String end = "10:00 PM";
        parentalControls.setPlaytimeLimits(start, end);
        
        String[] limits = parentalControls.getPlaytimeLimits();
        assertEquals(start, limits[0], "Start time should match the set value");
        assertEquals(end, limits[1], "End time should match the set value");
    }

    @Test
    public void testIsWithinAllowedTimeBeforeLimit() {
        // Mock current time to be 8:30 AM (before the end time)
        Mockito.mockStatic(LocalTime.class);
        Mockito.when(LocalTime.now()).thenReturn(LocalTime.of(8, 30));

        parentalControls.setPlaytimeLimits("09:00 AM", "09:00 PM");
        assertTrue(parentalControls.isWithinAllowedTime(), "The time should be within the allowed range");
    }

    @Test
    public void testIsWithinAllowedTimeAfterLimit() {
        // Mock current time to be 10:00 PM (after the end time)
        Mockito.mockStatic(LocalTime.class);
        Mockito.when(LocalTime.now()).thenReturn(LocalTime.of(22, 0));

        parentalControls.setPlaytimeLimits("09:00 AM", "09:00 PM");
        assertFalse(parentalControls.isWithinAllowedTime(), "The time should be outside the allowed range");
    }

    @Test
    public void testRevivePet() {
        int petIndex = 1;

        // Set pet state to dead initially
        parentalControls.revivePet(petIndex);
        
        // Verify pet is revived and health is set to 100
        assertTrue(parentalControls.getPetStates().get(petIndex), "Pet should be alive after revival");
        assertEquals(100, parentalControls.getPetHealth().get(petIndex), "Pet's health should be 100 after revival");
    }

    @Test
    public void testReviveAlreadyAlivePet() {
        int petIndex = 1;

        // Set pet state to alive
        parentalControls.revivePet(petIndex);
        
        // Try reviving the pet again
        boolean revived = parentalControls.revivePet(petIndex);
        
        // Ensure it does not revive an already alive pet
        assertFalse(revived, "Pet should not be revived if already alive");
    }

    @Test
    public void testGetStatistics() {
        Map<String, Integer> stats = parentalControls.getStatistics();
        
        // Validate that the returned statistics map is not null
        assertNotNull(stats, "Statistics should not be null");
        
        // Test the keys of the map
        assertTrue(stats.containsKey("totalPlayTime"), "Statistics should contain totalPlayTime");
        assertTrue(stats.containsKey("averagePlayTime"), "Statistics should contain averagePlayTime");
    }

    @Test
    public void testEnforcePlaytimeRestrictions() {
        // Mock current time to be outside allowed range (e.g., 10:00 PM)
        Mockito.mockStatic(LocalTime.class);
        Mockito.when(LocalTime.now()).thenReturn(LocalTime.of(22, 0));

        parentalControls.setPlaytimeLimits("09:00 AM", "09:00 PM");

        // Since the time is outside the allowed range, enforcePlaytimeRestrictions should stop the game.
        // We will mock JOptionPane.showMessageDialog to prevent the actual popup.
        Mockito.mockStatic(JOptionPane.class);
        parentalControls.enforcePlaytimeRestrictions();
        
        Mockito.verifyStatic(JOptionPane.class, Mockito.times(1));
        JOptionPane.showMessageDialog(null, "Playtime is not allowed at this time. Please try again later.", "Access Restricted", JOptionPane.WARNING_MESSAGE);
    }

    @Test
    public void testSaveAndLoadPetStates() {
        // Mock pet state data and test loading and saving
        parentalControls.revivePet(1);
        
        // We cannot test actual file IO in unit tests, so we mock the savePetStates method
        Mockito.mockStatic(CSVUtility.class);
        parentalControls.savePetStates();
        
        // Verify that savePetStates was called
        Mockito.verifyStatic(CSVUtility.class, Mockito.times(1));
        CSVUtility.saveToCSV(Mockito.anyString(), Mockito.anyList());
    }

    @Test
    public void testGetStartAndEndAllowedTime() {
        LocalTime start = parentalControls.getStartAllowedTime();
        LocalTime end = parentalControls.getEndAllowedTime();
        
        // Check if default times are set correctly
        assertEquals(LocalTime.of(9, 0), start, "Start time should be 9:00 AM by default");
        assertEquals(LocalTime.of(21, 0), end, "End time should be 9:00 PM by default");
    }
}
