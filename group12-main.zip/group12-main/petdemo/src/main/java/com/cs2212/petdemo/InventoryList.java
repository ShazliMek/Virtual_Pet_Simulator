package com.cs2212.petdemo;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is for the Inventory list.
 * 
 * @author Siddharth Singh
 */
public class InventoryList {

    private Inventory inventory;

    /**
     * This is the constructor for the class InventoryList.
     * 
     * @param inventory
     */
    public InventoryList(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * This method is for displaying the inventory list.
     * 
     * @return displayList
     */
    public List<String> getDisplayList() {
        List<String> displayList = new ArrayList<>();
        for (InventoryItem item : inventory.getItems()) {
            displayList.add(item.getName() + " (x" + item.getQuantity() + ")");
        }
        return displayList;
    }

    /**
     * This method is for using the item.
     * 
     * @param index
     * @param pet
     * @return boolean 
     */
    public boolean useItem(int index, Pet pet) {
        if (index >= 0 && index < inventory.getItems().size()) {
            InventoryItem item = inventory.getItems().get(index);
            if (item.getQuantity() > 0) {
                item.useItem(pet);
                item.decrementQuantity();
                if (item.getQuantity() == 0) {
                    inventory.removeItem(item.getName()); // Use the removeItem method from Inventory
                }
                return true;
            }
        }
        return false;
    }

    /** 
     * This method is for adding an item to the inventory.
     * 
     * @param name
     * @param quantity
     * @param type
     * @param effectValue
     */
    public void addItem(String name, int quantity, String type, int effectValue) {
        InventoryItem newItem = new InventoryItem(name, quantity, type, effectValue);
        inventory.addItem(newItem);
    }
    
    /**
     * This method is for getting the item count.
     * 
     * @return count
     */
    public int getItemCount() {
        int count = inventory.getItems().size();
        return count;
    }

    /**
     * This method is for getting the iventory item.
     * 
     * @param index
     * @return InvetoryItem
     */
    public InventoryItem getItem(int index) {
        if (index >= 0 && index < inventory.getItems().size()) {
            return inventory.getItems().get(index);
        }
        return null;
    }

    /**
     * This method is for getting the string of the inventory list.
     * 
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Inventory List:\n");
        for (String displayItem : getDisplayList()) {
            sb.append(displayItem).append("\n");
        }
        return sb.toString();
    }
}
