import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.swing.*;

public class SettingsTest {

    private settings settingsScreen;
    private ParentalControls mockParentalControls;
    private GameState mockGameState;

    @BeforeEach
    public void setUp() {
        mockParentalControls = Mockito.mock(ParentalControls.class);
        mockGameState = Mockito.mock(GameState.class);
        settingsScreen = new settings(mockParentalControls);
    }

    @Test
    public void testSetPlaytimeLimitsButtonAction() {
        // Simulate button click for SetPlaytimeLimits
        JButton setPlaytimeLimitsButton = (JButton) settingsScreen.getContentPane().getComponent(1);
        setPlaytimeLimitsButton.doClick();

        // Verify that a new setPlaytimeLimits screen is displayed
        Mockito.verify(settingsScreen).dispose();
        // Verify that a new setPlaytimeLimits instance is created and displayed
        Mockito.verify(settingsScreen, Mockito.times(1)).new setPlaytimeLimits(mockParentalControls);
    }

    @Test
    public void testStatisticsButtonAction() {
        // Simulate button click for Statistics
        JButton statisticsButton = (JButton) settingsScreen.getContentPane().getComponent(2);
        statisticsButton.doClick();

        // Verify that a new Statistics screen is displayed
        Mockito.verify(settingsScreen).dispose();
        // Verify that a new Statistics instance is created and displayed
        Mockito.verify(settingsScreen, Mockito.times(1)).new Statistics(mockParentalControls);
    }

    @Test
    public void testRevivePetButtonAction() {
        // Simulate button click for Revive Pet
        JButton revivePetButton = (JButton) settingsScreen.getContentPane().getComponent(3);
        revivePetButton.doClick();

        // Verify that a new revivePet screen is displayed
        Mockito.verify(settingsScreen).dispose();
        // Verify that a new revivePet instance is created with both parentalControls and GameSaveManager
        Mockito.verify(settingsScreen, Mockito.times(1)).new revivePet(mockParentalControls, Mockito.any(GameSaveManager.class));
    }

    @Test
    public void testBackButtonAction() {
        // Simulate button click for Back
        JButton backButton = (JButton) settingsScreen.getContentPane().getComponent(4);
        backButton.doClick();

        // Verify that a new MainMenu screen is displayed
        Mockito.verify(settingsScreen).dispose();
        // Verify that a new MainMenu instance is created and displayed
        Mockito.verify(settingsScreen, Mockito.times(1)).new MainMenu();
    }

    @Test
    public void testConstructorInitialization() {
        // Test the constructor behavior
        assertNotNull(settingsScreen);
        assertEquals(mockParentalControls, settingsScreen.parentalControls);
    }
}

