import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.io.File;
import javax.swing.*;

public class GameSlotTest {

    @Mock
    private File mockFile;
    
    @Mock
    private GameSaveManager mockGameSaveManager;

    private game_slot gameSlot;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        gameSlot = new game_slot();
    }

    // Test for ensureSaveDirectory
    @Test
    public void testEnsureSaveDirectory() {
        // Mock the behavior of the file
        File saveDir = new File("saves");
        when(mockFile.exists()).thenReturn(false);
        
        gameSlot.ensureSaveDirectory();
        
        // Verify the save directory was created (make sure ensureSaveDirectory calls mkdirs)
        verify(mockFile).mkdirs();
    }

    // Test for isSlotOccupied (when the file exists)
    @Test
    public void testIsSlotOccupiedWhenFileExists() {
        File saveFile = new File("saves/slot1.csv");
        when(mockFile.exists()).thenReturn(true);
        
        assertTrue(gameSlot.isSlotOccupied(0), "Slot should be occupied when the file exists");
    }

    // Test for isSlotOccupied (when the file does not exist)
    @Test
    public void testIsSlotOccupiedWhenFileDoesNotExist() {
        File saveFile = new File("saves/slot1.csv");
        when(mockFile.exists()).thenReturn(false);
        
        assertFalse(gameSlot.isSlotOccupied(0), "Slot should be empty when the file doesn't exist");
    }

    // Test for updateSlotButtons
    @Test
    public void testUpdateSlotButtons() {
        // Mock the slot state
        when(gameSlot.isSlotOccupied(0)).thenReturn(true);
        when(gameSlot.isSlotOccupied(1)).thenReturn(false);
        when(gameSlot.isSlotOccupied(2)).thenReturn(true);

        gameSlot.updateSlotButtons();

        // Verify the button text changes based on whether the slot is occupied or not
        assertEquals("Slot 1 (Load)", gameSlot.jButton1.getText());
        assertEquals("Slot 2 (Empty)", gameSlot.jButton2.getText());
        assertEquals("Slot 3 (Load)", gameSlot.jButton3.getText());
    }

    // Test for button actions (simulate button click for Slot 1)
    @Test
    public void testJButton1ActionPerformedStartNewGame() {
        // Simulate empty slot (no save file exists)
        when(gameSlot.isSlotOccupied(0)).thenReturn(false);

        // Capture the method that would be invoked when starting a new game
        doNothing().when(gameSlot).startNewGame(0);

        // Simulate button click
        gameSlot.jButton1.doClick();

        // Verify that startNewGame() is called when the slot is empty
        verify(gameSlot).startNewGame(0);
    }

    // Test for button actions (simulate button click for Slot 2)
    @Test
    public void testJButton2ActionPerformedLoadGame() {
        // Simulate occupied slot (save file exists)
        when(gameSlot.isSlotOccupied(1)).thenReturn(true);

        // Capture the method that would be invoked when loading a game
        doNothing().when(gameSlot).loadGame(1);

        // Simulate button click
        gameSlot.jButton2.doClick();

        // Verify that loadGame() is called when the slot is occupied
        verify(gameSlot).loadGame(1);
    }

    // Test for button actions (simulate button click for Slot 3)
    @Test
    public void testJButton3ActionPerformedStartNewGame() {
        // Simulate empty slot (no save file exists)
        when(gameSlot.isSlotOccupied(2)).thenReturn(false);

        // Capture the method that would be invoked when starting a new game
        doNothing().when(gameSlot).startNewGame(2);

        // Simulate button click
        gameSlot.jButton3.doClick();

        // Verify that startNewGame() is called when the slot is empty
        verify(gameSlot).startNewGame(2);
    }
}
