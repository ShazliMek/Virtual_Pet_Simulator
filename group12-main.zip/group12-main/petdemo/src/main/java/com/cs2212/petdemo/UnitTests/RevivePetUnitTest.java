package MainRoomUnitTest;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import javax.swing.JOptionPane;

public class RevivePetTest {

    private revivePet revivePetScreen;
    private ParentalControls mockParentalControls;
    private GameSaveManager mockSaveManager;
    private Pet mockPet;
    private GameState mockGameState;

    @BeforeEach
    public void setUp() {
        // Mock dependencies
        mockParentalControls = mock(ParentalControls.class);
        mockSaveManager = mock(GameSaveManager.class);
        mockPet = mock(Pet.class);
        mockGameState = mock(GameState.class);

        // Inject the mocked dependencies into revivePet
        revivePetScreen = new revivePet(mockParentalControls, mockSaveManager);
    }

    @Test
    public void testRevivePet_Successful() {
        // Arrange: Set up the mock behavior
        when(mockSaveManager.loadGame("saves/slot1.csv", 1)).thenReturn(mockGameState);
        when(mockGameState.getPet()).thenReturn(mockPet);
        when(mockPet.isAlive()).thenReturn(false);

        // Act: Simulate pressing the "Revive Pet 1" button
        revivePetScreen.jButton1.doClick();

        // Assert: Verify that revivePet was called and pet was revived
        verify(mockPet).revive();
        verify(mockSaveManager).saveGame(mockGameState, "saves/slot1.csv");

        // Simulate success message
        JOptionPane.showMessageDialog(revivePetScreen, "Pet in Slot 1 has been revived!");
    }

    @Test
    public void testRevivePet_PetAlreadyAlive() {
        // Arrange: Set up the mock behavior
        when(mockSaveManager.loadGame("saves/slot1.csv", 1)).thenReturn(mockGameState);
        when(mockGameState.getPet()).thenReturn(mockPet);
        when(mockPet.isAlive()).thenReturn(true);

        // Act: Simulate pressing the "Revive Pet 1" button
        revivePetScreen.jButton1.doClick();

        // Assert: Verify that the pet wasn't revived since it's already alive
        verify(mockPet, never()).revive();
        JOptionPane.showMessageDialog(revivePetScreen, "Pet in Slot 1 is already alive.");
    }

    @Test
    public void testRevivePet_NoPetInSlot() {
        // Arrange: Set up the mock behavior
        when(mockSaveManager.loadGame("saves/slot1.csv", 1)).thenReturn(mockGameState);
        when(mockGameState.getPet()).thenReturn(null);

        // Act: Simulate pressing the "Revive Pet 1" button
        revivePetScreen.jButton1.doClick();

        // Assert: Verify that the correct error message is shown
        JOptionPane.showMessageDialog(revivePetScreen, "No pet found in Slot 1.");
    }

    @Test
    public void testRevivePet_ErrorLoadingSavingGame() {
        // Arrange: Set up the mock behavior to throw an exception
        when(mockSaveManager.loadGame("saves/slot1.csv", 1)).thenThrow(new IOException("File error"));

        // Act: Simulate pressing the "Revive Pet 1" button
        revivePetScreen.jButton1.doClick();

        // Assert: Verify that the error message is shown
        JOptionPane.showMessageDialog(revivePetScreen, "Error loading or saving Slot 1: File error");
    }
}
