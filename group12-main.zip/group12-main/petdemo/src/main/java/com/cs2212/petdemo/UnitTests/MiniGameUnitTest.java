import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.*;
import java.util.ArrayList;

public class MinigameTest {

    private Minigame minigame;

    @BeforeEach
    public void setup() {
        minigame = new Minigame();
    }

    @Test
    public void testStarInitialPosition() {
        // Assert that the star's initial x position is 50
        assertEquals(50, minigame.star.x, "Star initial x position should be 50");
        // Assert that the star's initial y position is at the bottom of the board
        assertEquals(minigame.boardHeight - minigame.starHeight, minigame.star.y, "Star initial y position should be at the bottom of the board");
    }

    @Test
    public void testStarJump() {
        // Simulate a jump
        minigame.keyPressed(new java.awt.event.KeyEvent(minigame, 0, 0, 0, java.awt.event.KeyEvent.VK_SPACE));
        
        // Assert that the star's Y position changes (it should move upwards)
        assertTrue(minigame.star.y < minigame.boardHeight - minigame.starHeight, "Star should have moved upwards after jump");
    }

    @Test
    public void testStarCollisionWithBed() {
        // Place a bed in the path of the star
        Minigame.Block bed = minigame.new Block(45, minigame.boardHeight - minigame.starHeight, 64, 116, null); // Just a simple block
        minigame.bedArray.add(bed);

        // Move the star into the bed's location
        minigame.star.x = bed.x + 10; // Simulate collision scenario
        
        // Check collision
        assertTrue(minigame.collision(minigame.star, bed), "There should be a collision when star and bed overlap");
    }

    @Test
    public void testBedPlacement() {
        // Simulate bed placement
        minigame.placeBed();
        
        // Check that at least one bed was placed
        assertFalse(minigame.bedArray.isEmpty(), "At least one bed should be placed in the game");
    }

    @Test
    public void testScoreIncrement() {
        int initialScore = minigame.score;
        
        // Simulate one game loop
        minigame.move();
        
        // Score should have incremented by 1
        assertEquals(initialScore + 1, minigame.score, "Score should increment by 1 after each move");
    }

    @Test
    public void testGameOver() {
        // Force a game over situation
        minigame.gameOver = true;
        
        // Check if game over state is true
        assertTrue(minigame.gameOver, "The game should be in a game over state");
    }

    @Test
    public void testResetGame() {
        // Set game to over
        minigame.gameOver = true;
        minigame.score = 100;
        
        // Simulate key press to reset game
        minigame.keyPressed(new java.awt.event.KeyEvent(minigame, 0, 0, 0, java.awt.event.KeyEvent.VK_SPACE));

        // Assert that game is reset (gameOver should be false, score should be 0)
        assertFalse(minigame.gameOver, "Game over state should be reset");
        assertEquals(0, minigame.score, "Score should be reset to 0 after game reset");
    }

    @Test
    public void testBedRemovalAfterLimit() {
        // Simulate placing beds
        for (int i = 0; i < 12; i++) {
            minigame.placeBed();
        }
        
        // Assert that bed array does not exceed size of 10
        assertEquals(10, minigame.bedArray.size(), "Bed array should contain no more than 10 beds");
    }

}
