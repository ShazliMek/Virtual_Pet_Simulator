import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import javax.swing.*;

class MainMenuTest {

    /**
     * Test to ensure MainMenu initializes correctly.
     */
    @Test
    void testMainMenuInitialization() {
        MainMenu mainMenu = new MainMenu();

        assertNotNull(mainMenu, "MainMenu should be initialized.");
        assertTrue(mainMenu.isVisible(), "MainMenu should be visible upon initialization.");
    }

    /**
     * Test to validate button functionality in MainMenu.
     */
    @Test
    void testButtonFunctionality() {
        MainMenu mainMenu = new MainMenu();

        JButton newGameButton = (JButton) mainMenu.getContentPane().getComponent(0); // Adjust index for New Game button
        newGameButton.doClick();

        // Assert the new game action triggered correctly (mocked or real behavior check)
        assertFalse(mainMenu.isVisible(), "MainMenu should close upon starting a new game.");
    }
}
