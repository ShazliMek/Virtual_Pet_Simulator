import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import javax.swing.*;

class AppUnitTest {

    @Test
    void testMainMethodExecution() {
        // Validate that App.main() runs without throwing any exceptions
        assertDoesNotThrow(() -> {
            App.main(new String[]{});
        }, "App.main() should execute without throwing exceptions.");
    }

    @Test
    void testJFrameInitialization() {
        // Mock the JFrame setup in App.java
        int boardWidth = 750;
        int boardHeight = 250;

        JFrame frame = new JFrame("Bedtime Escape!");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Validate JFrame properties
        assertEquals("Bedtime Escape!", frame.getTitle(), "Frame title should match.");
        assertEquals(boardWidth, frame.getWidth(), "Frame width should match.");
        assertEquals(boardHeight, frame.getHeight(), "Frame height should match.");
        assertFalse(frame.isResizable(), "Frame should not be resizable.");
        assertEquals(JFrame.EXIT_ON_CLOSE, frame.getDefaultCloseOperation(), "Default close operation should be EXIT_ON_CLOSE.");
    }

    @Test
    void testJFrameVisibility() {
        // Ensure the JFrame is made visible
        JFrame frame = new JFrame("Bedtime Escape!");
        frame.setVisible(true);

        assertTrue(frame.isVisible(), "Frame should be visible after setVisible(true).");
    }
}
