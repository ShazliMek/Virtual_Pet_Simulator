import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import javax.swing.*;

class EgghatchedTest {

    /**
     * Test to verify that the Egghatched GUI initializes correctly with all components.
     */
    @Test
    void testGUIInitialization() {
        // Setup: Create a valid GameState and initialize Egghatched
        GameState gameState = new GameState(new Pet("Buddy", "Dog"), new Inventory(), new ParentalControls(), 0);
        Egghatched egghatched = new Egghatched(gameState, 0);

        // Verify: Ensure components like label, text pane, and button are initialized
        assertNotNull(egghatched, "Egghatched should be initialized.");
        assertNotNull(egghatched.getContentPane(), "Content pane should be initialized.");
    }

    /**
     * Test to ensure the button click in Egghatched triggers the correct behavior.
     */
    @Test
    void testButtonClickAction() {
        // Setup: Create a valid GameState and initialize Egghatched
        GameState gameState = new GameState(new Pet("Buddy", "Dog"), new Inventory(), new ParentalControls(), 0);
        Egghatched egghatched = new Egghatched(gameState, 0);

        // Simulate button click
        JButton playWithPetButton = (JButton) egghatched.getContentPane().getComponent(2); // Assuming button is the 3rd component
        playWithPetButton.doClick();

        // Verify: Check that the MainRoom is opened (mock behavior or check state)
        // Assuming MainRoom sets a visible state or a flag (adjust according to your implementation)
        assertTrue(egghatched.isVisible(), "Egghatched window should close and transition should occur.");
    }

    /**
     * Test to validate Egghatched handles null GameState gracefully.
     */
    @Test
    void testNullGameStateHandling() {
        // Setup: Create Egghatched with a null GameState
        Egghatched egghatched = new Egghatched(null, 0);

        // Verify: Ensure no exceptions occur and behavior is logged
        assertNotNull(egghatched, "Egghatched should initialize even with a null GameState.");
    }
}
