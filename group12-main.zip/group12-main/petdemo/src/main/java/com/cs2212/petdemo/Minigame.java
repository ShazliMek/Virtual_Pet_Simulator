import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
/**
 * This class is for the Minigame the player will play so that they can earn food and gift items. 
 * The quality of the items will depend on how high the player score is.
 * 
 * @author Alishba Asif
 *
 */
public class Minigame extends JPanel implements ActionListener, KeyListener {
	private static final long serialVersionUID = 1L;
	int boradWidth = 750;
	int boardHeight = 250;
	
	//images
	Image starImg;
	Image starDeadImg;
	Image starJumpImg;
	Image bed1Img;
	Image bed2Img;
	Image bed3Img;
	
	Image food1Img;
	Image food2Img;
	Image food3Img;
	Image food4Img;
	Image gift1Img;
	Image gift2Img;
	Image gift3Img;
	Image gift4Img;
	
	/**
	 * This class is for determining the size of a certain image.
	 * @author Alishba
	 *
	 */
	class Block {
		int x;
		int y;
		int width;
		int height;
		Image img;
		
		Block(int x, int y, int width, int height, Image img) {
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
			this.img = img;
		}
	}
	
	//star
	int starWidth = 88;
	int starHeight = 94;
	int starX = 50;
	int starY = boardHeight - starHeight;
	
	Block star;
	
	//bed
	int bed1Width = 64;
	int bed2Width = 128;
	int bed3Width = 192;
	
	int bedHeight = 116;
	int bedX = 700;
	int bedY = boardHeight - bedHeight;
	ArrayList<Block> bedArray;
	
	//physics
	int velocityX = -12; // bed moving speed
	int velocityY = 0; // character jump speed
	int gravity = 1;
	
	boolean gameOver = false;
	int score = 0;
	
	Timer gameLoop;
	Timer placeBedTimer;
	
	/**
	 * This is the constructor for the Minigame class.
	 */
	public Minigame() {
		setPreferredSize(new Dimension(boradWidth, boardHeight));
		setBackground(new Color(0, 0, 53));
		
		setFocusable(true);
		addKeyListener(this);
		
		
		//images for the Minigame
		starImg = new ImageIcon(getClass().getResource("./img/Star-Run.gif")).getImage();
		starDeadImg = new ImageIcon(getClass().getResource("./img/Star-Cry.png")).getImage();
		starJumpImg = new ImageIcon(getClass().getResource("./img/Star-Jump.png")).getImage();
		bed1Img = new ImageIcon(getClass().getResource("./img/Bed1.png")).getImage();
		bed2Img = new ImageIcon(getClass().getResource("./img/Bed2.png")).getImage();
		bed3Img = new ImageIcon(getClass().getResource("./img/Bed3.png")).getImage();
		
		//images for the inventory items
		food1Img = new ImageIcon(getClass().getResource("./img/Food1.png")).getImage();
		food2Img = new ImageIcon(getClass().getResource("./img/Food2.png")).getImage();
		food3Img = new ImageIcon(getClass().getResource("./img/Food3.png")).getImage();
		food4Img = new ImageIcon(getClass().getResource("./img/Food4.png")).getImage();
		gift1Img = new ImageIcon(getClass().getResource("./img/Gift1.png")).getImage();
		gift2Img = new ImageIcon(getClass().getResource("./img/Gift2.png")).getImage();
		gift3Img = new ImageIcon(getClass().getResource("./img/Gift3.png")).getImage();
		gift4Img = new ImageIcon(getClass().getResource("./img/Gift4.png")).getImage();
		
		//star
		star = new Block(starX, starY, starWidth, starHeight, starImg);
		
		//bed
		bedArray = new ArrayList<Block>();
		
		//game timer
		gameLoop = new Timer(1000/60, this);
		gameLoop.start();
		
		//place bed timer
		placeBedTimer = new Timer(1500, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				placeBed();
			}
		});
		placeBedTimer.start();
	}
	
	/**
	 * This method is for placing the bed obstacles on screen.
	 */
	void placeBed() {
		if (gameOver) {
			return;
		}
		
		double placeBedChance = Math.random(); //0 - 0.999999
		if (placeBedChance > .90) { //10% you get bed3
			Block bed = new Block(bedX, bedY, bed3Width, bedHeight, bed3Img);
			bedArray.add(bed);
		} 
		else if (placeBedChance > .70) { //20% you get bed2
			Block bed = new Block(bedX, bedY, bed2Width, bedHeight, bed2Img);
			bedArray.add(bed);
		}
		else if (placeBedChance > .50) { //20% you get bed1
			Block bed = new Block(bedX, bedY, bed1Width, bedHeight, bed1Img);
			bedArray.add(bed);
		}
		
		if (bedArray.size() > 10) {
			bedArray.remove(0); //remove the first bed from ArrayList
		}
	}
	
	/**
	 * This method for painting the screen.
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}
	
	/**
	 * This method displays the graphics of the game.
	 * @param g
	 */
	public void draw(Graphics g) {
		//star
		g.drawImage(star.img, star.x, star.y, star.width, star.height, null);
		
		//bed
		for (int i = 0; i < bedArray.size(); i++) {
			Block bed = bedArray.get(i);
			g.drawImage(bed.img, bed.x, bed.y, bed.width, bed.height, null);
		}
		g.setColor(Color.white);
		g.setFont(new Font("Courier", Font.PLAIN, 32));
		if (gameOver) {
			// game over screen
			setBackground(Color.black);
			g.drawString("Game Over: " + String.valueOf(score), 10, 35);
			
			if (score > 5000) {
				g.drawString("You received: 1st grade items!", 10, 90);
				g.drawImage(food1Img, 450, 50, 90, 90, null);
				g.drawImage(gift1Img, 530, 50, 90, 90, null);
			}
			else if (score > 3000) {
				g.drawString("You received: 2th grade items!", 10, 90);
				g.drawImage(food2Img, 450, 50, 90, 90, null);
				g.drawImage(gift2Img, 530, 50, 90, 90, null);
			}
			else if (score > 1000) {
				g.drawString("You received: 3th grade items!", 10, 90);
				g.drawImage(food3Img, 450, 50, 90, 90, null);
				g.drawImage(gift3Img, 530, 50, 90, 90, null);
			}
			else if (score > 500){
				g.drawString("You received: 4th grade items!", 10, 90);
				g.drawImage(food4Img, 450, 50, 90, 90, null);
				g.drawImage(gift4Img, 530, 50, 90, 90, null);
			}
			else {
				g.drawString("You received no items :( ", 10, 90);
			}
		}
		else {
			g.drawString(String.valueOf(score), 10, 35);
		}
		
	}

	/**
	 * This method is how the star character will move.
	 */
	public void move() {
		//star
		velocityY += gravity;
		star.y += velocityY;
		
		if (star.y > starY) {
			star.y = starY;
			velocityY = 0;
			star.img = starImg;
		}
		
		//bed 
		for (int i = 0; i < bedArray.size(); i++) {
			Block bed = bedArray.get(i);
			bed.x += velocityX;
			
			if (collision(star, bed )) {
				//itemGet(score);
				gameOver = true;
				star.img = starDeadImg;
			}
		}
		//score 
		score++;
	}
	
	/**
	 * This method checks if there is a collision.
	 * @param a
	 * @param b
	 * @return a rectangle of where the collision will be.
	 */
	boolean collision(Block a, Block b) {
		return  a.x < b.x + b.width && //a's top left corner doesn't reach b's top right corner
				a.x + a.width > b.x && //a's top right corner passes b's top left corner
				a.y < b.y + b.height && //a's top left corner doesn't reach b's bottom left corner
				a.y + a.height > b.y; //a's bottom left corner passes b's top left corner	
	}
	
	/**
	 * This method is what happens when action is performed.
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		move();
		repaint();
		if (gameOver) {
			placeBedTimer.stop();
			gameLoop.stop();
		}
	}

	/**
	 * This method is for what happens when the player presses the space Key.
	 * @param e
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			//System.out.println("JUMP!");
			if (star.y == starY) {
				velocityY = -21;
				star.img = starJumpImg;
			}
			
			if (gameOver) {
				// reset game by resetting conditions
				setBackground(new Color(0, 0, 53));
				star.y = starY;
				star.img = starImg;
				velocityY = 0;
				bedArray.clear();
				score = 0;
				gameOver = false;
				gameLoop.start();
				placeBedTimer.start();
			}
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void keyReleased(KeyEvent e) {}
}
