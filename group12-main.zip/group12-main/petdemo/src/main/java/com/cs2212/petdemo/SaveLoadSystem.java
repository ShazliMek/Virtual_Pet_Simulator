/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cs2212.petdemo;
import java.io.*;

/**
 * This class is for the save load system.
 * 
 * @author shazlimekrani
 */
public class SaveLoadSystem {

    /**
     * This method is for saving the game.
     * 
     * @param gameState
     * @param fileName
     */
    public static void saveGame(GameState gameState, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(gameState);
            System.out.println("Game saved successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This meathod is for loading the game.
     * 
     * @param filename
     * @return GameState
     */
    public static GameState loadGame(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return (GameState) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * This method is for saving the statistics.
     * 
     * @param stats
     * @param fileName
     */
    public void saveStatistics(Statistics stats, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(stats);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is for loading statistics.
     * 
     * @param fileName
     * @return Statistics
     */
    public Statistics loadStatistics(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return (Statistics) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new Statistics(new ParentalControls()); // Provide a default ParentalControls
        }
    }
}