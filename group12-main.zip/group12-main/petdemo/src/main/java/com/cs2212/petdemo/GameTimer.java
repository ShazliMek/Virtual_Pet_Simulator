package com.cs2212.petdemo;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.Timer;

/**
 * The class GameTimer class to manage periodic updates of the pet's stats and inventory.
 * 
 * @author Siddharth Singh
 */
public class GameTimer {

    private Timer petStatsTimer; // Swing Timer to schedule pet stat updates
    private Pet pet; // Reference to the pet
    private Inventory inventory; // Reference to the inventory
    private ScheduledExecutorService scheduler; // Executor for inventory updates

    /**
     * This is the constructor for class GameTimer.
     * 
     * @param pet       The pet whose stats will be updated.
     * @param inventory The inventory to update periodically.
     */
    public GameTimer(Pet pet, Inventory inventory) {
        if (pet == null) {
            throw new IllegalArgumentException("Pet cannot be null");
        }
        if (inventory == null) {
            throw new IllegalArgumentException("Inventory cannot be null");
        }

        this.pet = pet;
        this.inventory = inventory;

        // Timer for updating pet stats every 5 seconds
                this.petStatsTimer = new Timer(5000, e -> updatePetStats());

        // Initialize the ScheduledExecutorService for inventory updates
        this.scheduler = Executors.newScheduledThreadPool(1);
    }

    /**
     * This method starts both the pet stats timer and the inventory updater.
     */
    public void start() {
        if (!petStatsTimer.isRunning()) {
            petStatsTimer.start();
            System.out.println("Pet stats timer started.");
        }

        // Start the inventory updater
        startInventoryUpdater();
    }

    /**
     * This method stops both the pet stats timer and the inventory updater.
     */
    public void stop() {
        if (petStatsTimer.isRunning()) {
            petStatsTimer.stop();
            System.out.println("Pet stats timer stopped.");
        }

        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            System.out.println("Inventory updater stopped.");
        }
    }

    /**
     * This method updates the pet's stats periodically.
     */
    private void updatePetStats() {
        if (pet.isAlive()) {
            pet.updateStats(); // Call the updateStats() method from Pet
            System.out.println("Pet stats updated. Current state: " + pet.getState());

            if (!pet.isAlive()) {
                petStatsTimer.stop();
                System.out.println(pet.getName() + " has passed away. Timer stopped.");
                // Optionally, trigger a game over event here
            }
        }
    }

    /**
     * This method starts the inventory updater.
     */
    private void startInventoryUpdater() {
        scheduler.scheduleAtFixedRate(() -> {
            if (inventory != null) {
                for (InventoryItem item : inventory.getItems()) {
                    item.incrementQuantity(); // Increment with bounds inside InventoryItem
                }
                System.out.println("Inventory updated!");
            }
        }, 0, 10, TimeUnit.SECONDS); // Run every 10 seconds
    }

    /**
     * This method resets the GameTimer with a new pet and inventory.
     * 
     * @param newPet       The new pet to be managed by the timer.
     * @param newInventory The new inventory to be updated.
     */
    public void reset(Pet newPet, Inventory newInventory) {
        if (newPet == null) {
            throw new IllegalArgumentException("New pet cannot be null");
        }
        if (newInventory == null) {
            throw new IllegalArgumentException("New inventory cannot be null");
        }

        stop();
        this.pet = newPet;
        this.inventory = newInventory;
        start();
        System.out.println("GameTimer reset for new pet and inventory.");
    }

    /**
     * This method cleans up resources by stopping timers and shutting down executors.
     */
    public void dispose() {
        stop();
    }
}

