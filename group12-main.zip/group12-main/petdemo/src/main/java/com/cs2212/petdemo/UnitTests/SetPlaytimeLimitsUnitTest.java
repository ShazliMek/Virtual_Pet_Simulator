package MainRoomUnitTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.swing.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SetPlaytimeLimitsTest {

    private setPlaytimeLimits playtimeLimitsScreen;
    private ParentalControls mockParentalControls;

    @BeforeEach
    public void setUp() {
        mockParentalControls = Mockito.mock(ParentalControls.class);
        playtimeLimitsScreen = new setPlaytimeLimits(mockParentalControls);
    }

    @Test
    public void testLoadCurrentPlaytimeLimits() {
        // Mock the getPlaytimeLimits() method to return a set of limits
        String[] mockLimits = {"09:00 AM", "09:00 PM"};
        Mockito.when(mockParentalControls.getPlaytimeLimits()).thenReturn(mockLimits);

        // Load current limits into the form
        playtimeLimitsScreen.loadCurrentPlaytimeLimits();

        // Verify that the JComboBox selections are correct
        assertEquals("09", playtimeLimitsScreen.jComboBox1.getSelectedItem());
        assertEquals("00", playtimeLimitsScreen.jComboBox2.getSelectedItem());
        assertEquals("AM", playtimeLimitsScreen.jComboBox3.getSelectedItem());

        assertEquals("09", playtimeLimitsScreen.jComboBox4.getSelectedItem());
        assertEquals("00", playtimeLimitsScreen.jComboBox5.getSelectedItem());
        assertEquals("PM", playtimeLimitsScreen.jComboBox6.getSelectedItem());
    }

    @Test
    public void testGenerateValues() {
        // Test if the generateValues method correctly generates values for the start time
        String[] result = playtimeLimitsScreen.generateValues(1, 5);
        assertArrayEquals(new String[]{"01", "02", "03", "04", "05"}, result);
    }

    @Test
    public void testSaveActionPerformed() {
        // Set mock values for the JComboBoxes
        Mockito.when(playtimeLimitsScreen.jComboBox1.getSelectedItem()).thenReturn("09");
        Mockito.when(playtimeLimitsScreen.jComboBox2.getSelectedItem()).thenReturn("00");
        Mockito.when(playtimeLimitsScreen.jComboBox3.getSelectedItem()).thenReturn("AM");

        Mockito.when(playtimeLimitsScreen.jComboBox4.getSelectedItem()).thenReturn("09");
        Mockito.when(playtimeLimitsScreen.jComboBox5.getSelectedItem()).thenReturn("00");
        Mockito.when(playtimeLimitsScreen.jComboBox6.getSelectedItem()).thenReturn("PM");

        // Perform the Save action
        playtimeLimitsScreen.SaveActionPerformed(null);

        // Verify the setPlaytimeLimits method is called on the mockParentalControls object
        Mockito.verify(mockParentalControls).setPlaytimeLimits("09:00", "09:00");
        
        // Verify that the JOptionPane message dialog is called with the success message
        Mockito.verify(playtimeLimitsScreen, Mockito.times(1)).showMessageDialog(
                Mockito.any(), Mockito.eq("Playtime limits updated successfully!")
        );
    }

    @Test
    public void testBackActionPerformed() {
        // Simulate Back button click
        playtimeLimitsScreen.BackActionPerformed(null);

        // Verify that a new settings screen is opened
        Mockito.verify(mockParentalControls, Mockito.times(1)).setPlaytimeLimits(Mockito.any(), Mockito.any());
    }
}

