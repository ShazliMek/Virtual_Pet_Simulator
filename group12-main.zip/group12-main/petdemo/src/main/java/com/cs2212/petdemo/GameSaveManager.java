package com.cs2212.petdemo;

import java.io.*;
import java.util.*;

/**
 * This class is for the managing the game saves.
 * 
 * @author Siddharth Singh
 */
public class GameSaveManager {
    private static final String SAVE_FOLDER = "saves" + File.separator;

    /**
     * This method saves the game state to a file.
     * 
     * @param gameState The game state to save.
     * @param fileName The file name to save the state to.
     * @throws IOException If an I/O error occurs.
     */
    public void saveGame(GameState gameState, String fileName) throws IOException {
        // Ensure the save folder exists
        File saveDir = new File(SAVE_FOLDER);
        if (!saveDir.exists() && !saveDir.mkdirs()) {
            throw new IOException("Failed to create save directory: " + SAVE_FOLDER);
        }

        // Prepend SAVE_FOLDER only if not already included
        String fullPath = fileName.startsWith(SAVE_FOLDER) || new File(fileName).isAbsolute()
            ? fileName
            : SAVE_FOLDER + fileName;

        // Serialize and save
        List<String[]> data = new ArrayList<>();
        Pet pet = gameState.getPet();
        if (pet != null) {
            data.add(new String[]{
                "Pet", pet.getName(), pet.getType(),
                String.valueOf(pet.getHealth()), String.valueOf(pet.getHappiness()),
                String.valueOf(pet.getSleep()), String.valueOf(pet.getFullness()),
                String.valueOf(pet.isAlive())
            });
        }

        data.add(new String[]{"Score", String.valueOf(gameState.getScore())});

        Inventory inventory = gameState.getInventory();
        if (inventory != null) {
            for (InventoryItem item : inventory.getItems()) {
                data.add(new String[]{
                    "Item", item.getName(), String.valueOf(item.getQuantity()), item.getType(), String.valueOf(item.getEffectValue())
                });
            }
        }

        CSVUtility.saveToCSV(fullPath, data);
    }

    /**
     * This method loads the game state from a file.
     * 
     * @param fileName The file name to load the state from.
     * @param slotIndex The save slot index.
     * @return The loaded game state.
     * @throws IOException If an I/O error occurs.
     */
    public GameState loadGame(String fileName, int slotIndex) throws IOException {
        // Ensure the file name has the full path
        String fullPath = fileName.startsWith(SAVE_FOLDER) ? fileName : SAVE_FOLDER + fileName;

        // Load data from CSV
        List<String[]> data = CSVUtility.loadFromCSV(fullPath);
        Pet pet = null;
        Inventory inventory = new Inventory();
        int score = 0;

        // Deserialize the data
        for (String[] row : data) {
            switch (row[0]) {
                case "Pet":
                    pet = new Pet(row[1], row[2]);
                    pet.setHealth(Integer.parseInt(row[3]));
                    pet.setHappiness(Integer.parseInt(row[4]));
                    pet.setSleep(Integer.parseInt(row[5]));
                    pet.setFullness(Integer.parseInt(row[6]));
                    break;
                case "Score":
                    score = Integer.parseInt(row[1]);
                    break;
                case "Item":
                    inventory.addItem(new InventoryItem(row[1], Integer.parseInt(row[2]), row[3], Integer.parseInt(row[4])));
                    break;
            }
        }

        // Return a GameState object with the slot index included
        return new GameState(pet, inventory, new ParentalControls(), score, slotIndex);
    }
}
