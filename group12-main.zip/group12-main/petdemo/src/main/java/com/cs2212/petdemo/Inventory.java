package com.cs2212.petdemo;

import com.cs2212.petdemo.InventoryItem;
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import javax.swing.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This class represents the inventory of the player.
 * 
 * @author Jagjot Singh Bisram
 */
public class Inventory {
    private List<InventoryItem> items = new ArrayList<>();
    final static int MAX_ITEM_COUNT = 20;

    /**
     * This is the constructor for the class Inventory.
     */
    public Inventory() {
        initializeDefaultItems();
        startItemIncrementTimer();
    }

    /**
     * This method initializes the defult items in the inventory.
     */
    private void initializeDefaultItems() {
        items.add(new InventoryItem("Pizza", 10, "food", 10));
        items.add(new InventoryItem("Burger", 10, "food", 15));
        items.add(new InventoryItem("CottonCandy", 10, "food", 5));
        items.add(new InventoryItem("Drink", 10, "food", 8));
        items.add(new InventoryItem("Gift1", 10, "gift", 10));
        items.add(new InventoryItem("Gift2", 10, "gift", 12));
        items.add(new InventoryItem("Ears", 10, "gift", 15));
        items.add(new InventoryItem("PartyHat", 10, "gift", 20));
    }

    /**
     * This ethod starts the item increment timer.
     */
    public void startItemIncrementTimer() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                incrementItems();
            }
        }, 0, 30000); // Every 10 seconds
    }

    /**
     * This method is how the items will increment.
     */
    private void incrementItems() {
        for (InventoryItem item : items) {
            if (item.getQuantity() < MAX_ITEM_COUNT) {
                item.incrementQuantity();
            }
        }
    }
    
    /** 
     * This methos is for adding and item to the inventory.
     * 
     * @param item
     */
    public void addItem(InventoryItem item) {
        items.add(item);
    }
    
    /**
     * This method is for removing an item from the inventory.
     * 
     * @param itemName
     */
    public void removeItem(String itemName) {
        Iterator<InventoryItem> iterator = items.iterator();
        while (iterator.hasNext()) {
            InventoryItem item = iterator.next();
            if (item.getName().equals(itemName)) {
                iterator.remove();
                break;
            }
        }
    }

    /**
     * This method is for using the item with a given name.
     * 
     * @param name
     * @param boolean
     */
    public boolean useItemByName(String name) {
        InventoryItem item = getItemByName(name);
        if (item != null && item.getQuantity() > 0) {
            item.decrementQuantity();
            if (item.getQuantity() == 0) {
                removeItem(name); // Optionally remove if quantity is zero
            }
            return true;
        }
        return false; // Return false if the item doesn't exist or quantity is zero
    }

    /** 
     * This method is for getting the inventory item by a given name.
     * 
     * @param name
     * @return InventoryItem
     */
    public InventoryItem getItemByName(String name) {
        for (InventoryItem item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null; // Return null if the item is not found
    }

    /**
     * This method is for getting the items form the inventory.
     * 
     * @return List<InventoryItem>
     */
    public List<InventoryItem> getItems() {
        return items;
    }
}
