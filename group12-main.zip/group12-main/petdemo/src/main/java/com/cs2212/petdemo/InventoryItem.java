/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cs2212.petdemo;
import java.io.Serializable;

/**
 * This class IventoryItem is for the items in the inventory.
 * 
 * @author shazlimekrani
 */
public class InventoryItem implements Serializable {

    private String name;
    private int quantity; // Number of this item in inventory
    private int effectValue; // Effect value when used (e.g., +10 health)
    private String type;
    private final int MAX_ITEM_COUNT = 20;

    /**
     * This is the constructor for InventoryItem
     * 
     * @param name
     * @param quanitity 
     * @param type
     * @param effectValue
     */
    public InventoryItem(String name, int quantity, String type, int effectValue) {
        this.name = name;
        this.quantity = quantity;
        this.type = type;
        this.effectValue = effectValue;
    }
    
    /**
     * This method is for getting the type.
     * 
     * @return type
     */
     public String getType() {
        return type;
    }

    /**
     * This method is for incrementing the quantity.
     */
    public void incrementQuantity() {
        if (this.quantity < Inventory.MAX_ITEM_COUNT) { // Assuming MAX_ITEM_COUNT is static in Inventory
            this.quantity++;
        }
    }   
     
    /**
     * This method is to get the name of the item.
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * This method is for getting the quantity of the item.
     * 
     * @return quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * This method is for setting the quantity of the item.
     * 
     * @param quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * This method is for incrementing the quantity of the item.
     * 
     * @param amount
     */
    public void incrementQuantity(int amount) {
        this.quantity += amount;
    }

    /**
     * This method is for iecrementing the quantity of the item.
     */
    public void decrementQuantity() {
        if (this.quantity > 0) {
            this.quantity--;
        }
    }

    /**
     * This method is for getting the effect value of the item.
     * 
     * @return effectValue
     */
    public int getEffectValue() {
        return effectValue;
    }

    /**
     * This method is for using the item.
     * 
     * @param pet
     */
    public void useItem(Pet pet) {
        pet.setFullness(Math.min(pet.getFullness() + effectValue, pet.getMaxFullness()));
        System.out.println(name + " was used. Pet fullness: " + pet.getFullness());
    }
    
    /**
     * This method is for applying the item's effect to the pet.
     * 
     * @param pet
     */
    public void applyEffect(Pet pet) {
        // Default implementation or leave empty for subclasses to override
        
    }

    /**
     * This method is for getting the string for the name and quantity.
     * 
     * @return String
     */
    @Override
    public String toString() {
        return name + " (x" + quantity + ")";
    }
}
