/*import com.cs2212.petdemo.GameState;
import com.cs2212.petdemo.Inventory;
import com.cs2212.petdemo.Minigame;
import com.cs2212.petdemo.Pet;
import javax.swing.*;

/**
 * This class is for using with the Minigame class.
 * 
 * @author Alishba Asif
 */
/*public class App {
    public static void main(String[] args) {
        // Create the required objects for GameState
        Pet pet = new Pet("Buddy", "Dog"); // Ensure Pet constructor matches
        Inventory inventory = new Inventory(); // Ensure Inventory is implemented
        ParentalControls parentalControls = new ParentalControls(); // If needed
        int score = 0;

        // Create the GameState object
        GameState gameState = new GameState(pet, inventory, parentalControls, score);

        // Set up the JFrame
        int boardWidth = 750;
        int boardHeight = 250;

        JFrame frame = new JFrame("Bedtime Escape!");
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a Minigame instance with the GameState
        Minigame minigame = new Minigame(gameState);
        frame.add(minigame);
        frame.pack();

        // Request focus for the game panel and make the frame visible
        minigame.requestFocus();
        frame.setVisible(true);
    }
}*/
