package com.cs2212.petdemo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TutorialTest {

    private Tutorial tutorial;

    @BeforeEach
    public void setUp() {
        tutorial = new Tutorial();
    }

    @Test
    public void testTutorialInitialization() {
        // Check if the tutorial frame is initialized correctly
        assertNotNull(tutorial, "Tutorial frame should be initialized.");
    }

    @Test
    public void testImageSetToLabel() {
        // Test if the image is set correctly to the label
        tutorial.setImageToLabel();

        // Verify that the image has been set to the label (jLabel2)
        assertNotNull(tutorial.jLabel2.getIcon(), "Image should be set to jLabel2.");
        
        // Check that the icon is of type ImageIcon
        assertTrue(tutorial.jLabel2.getIcon() instanceof ImageIcon, "Icon of jLabel2 should be of type ImageIcon.");
    }

    @Test
    public void testBackButtonAction() {
        // Mock the close action on the back button
        tutorial.backActionPerformed(null);
        
        // Verify that the window is closed after the back button is clicked
        assertFalse(tutorial.isVisible(), "Tutorial window should be closed after clicking the back button.");
    }

    @Test
    public void testMainMethod() {
        // Test if the main method runs without errors
        assertDoesNotThrow(() -> Tutorial.main(new String[]{}), "Main method should not throw any exceptions.");
    }

    @Test
    public void testUIComponentVisibility() {
        // Test if the components are visible when the tutorial frame is shown
        tutorial.setVisible(true);

        assertTrue(tutorial.jLabel1.isVisible(), "Label 1 (Tutorial) should be visible.");
        assertTrue(tutorial.jLabel2.isVisible(), "Label 2 (Image) should be visible.");
        assertTrue(tutorial.back.isVisible(), "Back button should be visible.");
    }
}

