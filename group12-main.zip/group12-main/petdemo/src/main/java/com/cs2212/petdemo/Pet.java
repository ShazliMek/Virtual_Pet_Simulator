/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cs2212.petdemo;

import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import javax.swing.*;
import java.io.Serializable;

import java.util.Timer;
import java.util.TimerTask;

/**
 * This class Pet is for handaling the pet atributes and states.
 * 
 * @author Siddharth Singh
 */
public class Pet implements Serializable{
    // Attributes
    private String name;
    private String type;
    private int health;
    private int happiness;
    private int sleep;
    private int fullness;
    private boolean isAlive;
    private PetState state;

    // Constants for maximum values
    private final int maxHealth = 100;     // Max health
    private final int maxHappiness = 100; // Max happiness
    private final int maxSleep = 100;     // Max sleep
    private final int maxFullness = 100;  // Max fullness

    private transient Timer timer;
    
    /**
     * This is the constructor for the Pet class
     */
    public Pet(String name, String type) {
        this.name = name;
        this.type = type;
        this.health = maxHealth; // Default to max health
        this.happiness = 50;
        this.sleep = 50;
        this.fullness = 50;
        this.isAlive = true;
        this.state = PetState.HAPPY; // Default state
        
        startHealthDecay();
    }
    
    /**
     * This method is for automating the health decay.
     */
    private void startHealthDecay() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (isAlive) {
                    health = Math.max(health - 10, 0); // Decrease health by 10
                    if (health == 0) {
                        isAlive = false; // Mark the pet as dead
                        timer.cancel();
                    }
                }
            }
        }, 0, 10000); // Run every 10 seconds
    }
    
    /**
     * This method is for reviving the pet.
     */
    public void revive() {
        if (!isAlive) {
            isAlive = true;
            health = 50; // Reset health to a baseline value
            startHealthDecay();
        }
    }

    /**
     * This method is for feeding the pet, this increases fullness.
     * 
     * @param food
     */
    public void feed(FoodInventory food) {
        if (!isAlive) {
            System.out.println(name + " is no longer with us...");
            return;
        }
        fullness = Math.min(fullness + food.getEffectValue(), maxFullness);
        System.out.println(name + " was fed and now has fullness: " + fullness);
        checkState();
    }

    /**
     * This method is for playing with the pet, this increases happiness, lowers sleep and fullness.
     */
    public void play() {
        if (!isAlive) {
            System.out.println(name + " is no longer with us...");
            return;
        }
        happiness = Math.min(happiness + 10, 100); // Increment happiness but cap at 100
        sleep = Math.max(sleep - 10, 0); // Sleep decreases by 10
        fullness = Math.max(fullness - 10, 0); // Fullness decreases by 10
        System.out.println(name + " played! Happiness: " + happiness + ", Sleep: " + sleep + ", Fullness: " + fullness);
        checkState();
    }

    /**
     * This method is for letting the pet sleep, this gradually increases sleep.
     */
    public void goToBed() {
        if (!isAlive) {
            System.out.println(name + " is no longer with us...");
            return;
        }
        while (sleep < maxSleep) {
            sleep = Math.min(sleep + 10, maxSleep); // Sleep increases gradually
            System.out.println(name + " is sleeping. Sleep: " + sleep);
        }
        System.out.println(name + " is fully rested!");
        checkState();
    }

    /**
     * This method is for exercising the pet, this decreases sleep and fullness, increases health
     */
    public void exercise() {
        if (!isAlive) {
            System.out.println(name + " is no longer with us...");
            return;
        }
        sleep = Math.max(sleep - 20, 0); // Sleep decreases by 20
        fullness = Math.max(fullness - 20, 0); // Fullness decreases by 20
        health = Math.min(health + 20, maxHealth); // Health increases by 20
        System.out.println(name + " exercised! Health: " + health + ", Sleep: " + sleep + ", Fullness: " + fullness);
        checkState();
    }

    /**
     * This method is for taking the pet to the vet, this increases health
     */
    public void takeToVet() {
        if (!isAlive) {
            System.out.println(name + " is no longer with us...");
            return;
        }
        happiness = Math.max(happiness - 5, 0); // Decrement happiness but ensure it doesn't go below 0
        System.out.println(name + " went to the vet. Health: " + health);
        checkState();
    }

    /**
     * This method is for periodically updating stats, natural decay over time.
     */
    public void updateStats() {
        if (!isAlive) return;
        fullness = Math.max(fullness - 5, 0); // Fullness decreases by 5
        sleep = Math.max(sleep - 5, 0);      // Sleep decreases by 5
        happiness = Math.max(happiness - 5, 0); // Happiness decreases by 5
        System.out.println("Updated stats -> Fullness: " + fullness + ", Sleep: " + sleep + ", Happiness: " + happiness);
        checkState();
    }
    
    /**
     * This method is for feeding the pet.
     * 
     * @param effectValue
     */
    public void feed(int effectValue) {
        if (!isAlive()) {
            System.out.println(getName() + " cannot be fed because it is no longer alive.");
            return;
        }

        // Assuming fullness is the main attribute affected by feeding
        fullness += effectValue;

        // Cap the fullness to a maximum of 100
        if (fullness > 100) {
            fullness = 100;
        }
        
        health += effectValue / 2; // Example: Add half the effect value to happiness
        if (health > 100) {
            health = 100;
        }

        // Optional: Boost happiness slightly on feeding
        happiness += effectValue / 2; // Example: Add half the effect value to happiness
        if (happiness > 100) {
            happiness = 100;
        }

        System.out.println(getName() + " was fed. Fullness: " + fullness + ", Happiness: " + happiness);
    }
    
    /**
     * This method is to check and update the pet's state
     */
    public void checkState() {
        if (health <= 20 || fullness <= 10 || sleep <= 10) {
            state = PetState.CRITICAL;
        } else if (fullness <= 30) {
            state = PetState.HUNGRY;
        } else if (sleep <= 30) {
            state = PetState.TIRED;
        } else if (happiness >= 70 && health >= 70 && fullness >= 70) {
            state = PetState.HAPPY;
        } else {
            state = PetState.NORMAL;
        }

        if (health <= 0) {
            isAlive = false;
            state = PetState.CRITICAL;
            System.out.println(name + " has passed away...");
        } else {
            System.out.println(name + " is now in state: " + state);
        }
    }

    /**
     * This method is for getting happiness.
     * 
     * @return happiness
     */
    public int getHappiness() {
        return happiness;
    }

    /**
     * This method is for getting max happiness.
     * 
     * @return maxHappiness
     */
    public int getMaxHappiness() {
        return maxHappiness;
    }

    /**
     * This method is for settng happiness.
     * 
     * @param happiness
     */
    public void setHappiness(int happiness) {
        this.happiness = happiness;
    }

    /**
     * This method is for getting fullness.
     * 
     * @return fullness
     */
    public int getFullness() {
        return fullness;
    }

    /**
     * This method is for getting max fullness.
     * 
     * @return maxFullness
     */
    public int getMaxFullness() {
        return maxFullness;
    }

    /**
     * This method is for setting fullness.
     * 
     * @param fullness
     */
    public void setFullness(int fullness) {
        this.fullness = fullness;
    }

    /**
     * This method is for getting name.
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * This method is for checking if the pet is alive.
     * 
     * @return isAlive
     */
    public boolean isAlive() {
        return isAlive;
    }

    /**
     * This method is for getting the pet's state.
     * 
     * @return state
     */
    public PetState getState() {
        return state;
    }
    
    /**
     * This method is for getting the type.
     * 
     * @return type
     */
    public String getType(){
        return type;
    }

    /**
     * This method is for setting if the pet is alive.
     * 
     * @param b
     */
    public void setAlive(boolean b) {
        this.isAlive = true; 
    }

    /**
     * This method is for getting the max health.
     * 
     * @return health
     */
    public int getMaxHealth() {
        return this.health = 100; 
    }
    
    /**
     * This method is for the nested Enum for PetState
     */
    public enum PetState {
        HAPPY,
        HUNGRY,
        TIRED,
        CRITICAL,
        NORMAL
    }
    
    /**
     * This method is for getting the health.
     * 
     * @return health
     */
    public int getHealth() {
        return health;
    }

    /**
     * This method is for setting the health.
     * 
     * @param health
     */
    public void setHealth(int health) {
        this.health = Math.min(health, maxHealth);
        checkState();
    }

    /**
     * This method is for getting sleep.
     * 
     * @return sleep
     */
    public int getSleep() {
        return sleep;
    }

    /**
     * This method is for setting sleep.
     * 
     * @param sleep
     */
    public void setSleep(int sleep) {
        this.sleep = Math.min(sleep, maxSleep);
        checkState();
    }
}
