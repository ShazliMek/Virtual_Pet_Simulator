import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    /**
     * Test to ensure Inventory initializes with default items.
     */
    @Test
    void testInventoryInitialization() {
        Inventory inventory = new Inventory();

        assertNotNull(inventory.getItems(), "Inventory items should be initialized.");
        assertTrue(inventory.getItems().size() > 0, "Inventory should contain default items.");
    }

    /**
     * Test to add and retrieve items in Inventory.
     */
    @Test
    void testAddAndGetItem() {
        Inventory inventory = new Inventory();
        InventoryItem newItem = new InventoryItem("TestItem", 5, "type", 10);

        inventory.addItem(newItem);

        assertNotNull(inventory.getItemByName("TestItem"), "Added item should be retrievable by name.");
        assertEquals(5, inventory.getItemByName("TestItem").getQuantity(), "Item quantity should match.");
    }

    /**
     * Test to use an item in Inventory.
     */
    @Test
    void testUseItem() {
        Inventory inventory = new Inventory();
        InventoryItem newItem = new InventoryItem("TestItem", 1, "type", 10);

        inventory.addItem(newItem);
        boolean result = inventory.useItemByName("TestItem");

        assertTrue(result, "Using the item should return true.");
        assertNull(inventory.getItemByName("TestItem"), "Item should be removed when quantity reaches zero.");
    }
}
