package com.cs2212.petdemo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StartingRoomTest {

    private GameState gameState;
    private int slotIndex;
    private StartingRoom startingRoom;
    private JButton hatchEggButton;

    @BeforeEach
    public void setUp() {
        // Setup test data
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 0;
        slotIndex = 0;
        gameState = new GameState(null, inventory, parentalControls, score, slotIndex);

        // Create StartingRoom instance
        startingRoom = new StartingRoom(gameState, slotIndex);
        
        // Mocking or obtaining the components to simulate button click
        hatchEggButton = startingRoom.getJToggleButton1(); // Assuming the button is accessible
    }

    @Test
    public void testStartingRoomInitialization() {
        // Test if the StartingRoom is initialized correctly with a valid GameState
        assertNotNull(startingRoom, "StartingRoom should not be null.");
        assertEquals(gameState, startingRoom.getGameState(), "GameState should be correctly passed to the StartingRoom.");
        assertEquals(slotIndex, startingRoom.getSlotIndex(), "Slot index should be correctly passed to the StartingRoom.");
    }

    @Test
    public void testButtonLabel() {
        // Test if the button label is correctly set
        assertEquals("Click Here To Hatch Egg", hatchEggButton.getText(), "Button text should be 'Click Here To Hatch Egg'.");
    }

    @Test
    public void testButtonActionListener() {
        // Mocking the behavior of the ActionListener
        Egghatched eggHatchedScreen = mock(Egghatched.class);

        // Simulate button click
        hatchEggButton.doClick();

        // Verify that the new screen is shown after button click
        verify(eggHatchedScreen).setVisible(true);
    }

    @Test
    public void testButtonClickDisposesCurrentFrame() {
        // Assuming that the 'dispose' method will be called after button click
        StartingRoom spyStartingRoom = spy(startingRoom);

        // Simulate button click
        hatchEggButton.doClick();

        // Verify that the 'dispose' method is called on the current frame
        verify(spyStartingRoom).dispose();
    }

    @Test
    public void testMainMethod() {
        // Test if the main method runs correctly by checking if StartingRoom is created
        assertDoesNotThrow(() -> {
            StartingRoom.main(new String[]{});
        }, "Main method should not throw any exceptions.");
    }

    @Test
    public void testUIComponentVisibility() {
        // Test if the label and button are visible when the frame is packed
        startingRoom.setVisible(true);

        assertTrue(startingRoom.getJLabel1().isVisible(), "Label should be visible.");
        assertTrue(hatchEggButton.isVisible(), "Button should be visible.");
    }
}
