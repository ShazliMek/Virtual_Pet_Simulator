import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GameStateTest {

    /**
     * Test to ensure GameState initializes correctly with all components.
     */
    @Test
    void testGameStateInitialization() {
        Pet pet = new Pet("Buddy", "Dog");
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 100;
        int slotIndex = 1;

        GameState gameState = new GameState(pet, inventory, parentalControls, score, slotIndex);

        assertNotNull(gameState, "GameState should be initialized.");
        assertEquals("Buddy", gameState.getPet().getName(), "Pet name should be set correctly.");
        assertEquals(score, gameState.getScore(), "Score should be initialized correctly.");
        assertEquals(slotIndex, gameState.getSlotIndex(), "Slot index should be set correctly.");
    }

    /**
     * Test to validate saving and loading of GameState.
     */
    @Test
    void testGameStateSaveAndLoad() {
        Pet pet = new Pet("Buddy", "Dog");
        Inventory inventory = new Inventory();
        ParentalControls parentalControls = new ParentalControls();
        int score = 100;
        int slotIndex = 1;

        GameState gameState = new GameState(pet, inventory, parentalControls, score, slotIndex);
        gameState.save("test_save.csv", slotIndex);

        GameState loadedGameState = GameState.load("test_save.csv", slotIndex);

        assertNotNull(loadedGameState, "Loaded GameState should not be null.");
        assertEquals("Buddy", loadedGameState.getPet().getName(), "Loaded pet name should match the original.");
        assertEquals(score, loadedGameState.getScore(), "Loaded score should match the original.");
    }
}
