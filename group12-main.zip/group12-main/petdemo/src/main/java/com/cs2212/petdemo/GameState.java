/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cs2212.petdemo;

import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import javax.swing.*;
import java.io.Serializable;

import java.io.IOException;
import java.time.LocalTime;

/**
 * This class is for the game state.
 * 
 * @author Siddharth Singh
 */
public class GameState {
    private Pet pet;
    private Inventory inventory;
    private ParentalControls parentalControls;
    private int score;
    private int slotIndex;
    private LocalTime startAllowedTime;
    private LocalTime endAllowedTime;

    /** 
     * This is the constructor for the GameState class.
     * @param pet
     * @param inventory
     * @param parentalControls
     * @param slotIndex
     */
    public GameState(Pet pet, Inventory inventory, ParentalControls parentalControls, int score, int slotIndex) {
        this.pet = pet;
        this.inventory = inventory != null ? inventory : new Inventory();    
        this.parentalControls = parentalControls;
        this.score = score;
        this.slotIndex = slotIndex;
    }
    /**
     * This method is for getting the inventory.
     * 
     * @return inventory
     */
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * This method is for setting the inventory.
     * 
     * @param inventory
     */
    // Setter for Inventory
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
    
    public int getSlotIndex() {
        return slotIndex;
    }

    /**
     * This method is for setting the slot index.
     * 
     * @param slotIndex
     */
    public void setSlotIndex(int slotIndex) {
        this.slotIndex = slotIndex;
    }
    
    /**
     * This method is for setting the pet.
     * 
     * @param pet
     */
    public void setPet(Pet pet) {
        this.pet = pet;
    }

    /** 
     * This method is for gettting the pet.
     * 
     * @return Pet
     */
    public Pet getPet() {
        return pet;
    }
    
    /**
     * This method is for setting the score.
     * 
     * @param score
     */
    public void setScore(int score) {
        this.score = score;
    }

    /** 
     * This method is for getting the score.
     * 
     * @return score 
     */
    public int getScore() {
        return score;
    }

    /**
     * This method for saving the game state to CSV.
     * 
     * @param filePath
     * @param slotIndex
     */
    public void save(String filePath, int slotIndex) {
        List<String[]> data = new ArrayList<>();
        data.add(new String[]{"SlotIndex", String.valueOf(slotIndex)}); // Save slotIndex
        data.add(new String[]{"Pet", pet.getName(), pet.getType(), String.valueOf(pet.getHealth()),
                String.valueOf(pet.getSleep()), String.valueOf(pet.getFullness()), String.valueOf(pet.getHappiness())});

        for (InventoryItem item : inventory.getItems()) {
            data.add(new String[]{"Item", item.getName(), String.valueOf(item.getQuantity()), String.valueOf(item.getEffectValue())});
        }

        data.add(new String[]{"Score", String.valueOf(score)});
        
        try {
            CSVUtility.saveToCSV(filePath, data);
        } catch (IOException e) {
            System.err.println("Failed to save game state: " + e.getMessage());
        }
    }
   
    /**
     * This method is for loading the game state from CSV.
     * 
     * @param filePath
     * @param slotIndex
     * @return GameState
     */
    public static GameState load(String filePath, int slotIndex) {
        try {
            List<String[]> data = CSVUtility.loadFromCSV(filePath);
            Pet pet = null;
            Inventory inventory = new Inventory();
            ParentalControls parentalControls = new ParentalControls();
            int score = 0;
            

            for (String[] line : data) {
                switch (line[0]) {
                    case "SlotIndex":
                        slotIndex = Integer.parseInt(line[1]);
                        break;
                    case "Pet":
                        pet = new Pet(line[1], line[2]);
                        pet.setHealth(Integer.parseInt(line[3]));
                        pet.setSleep(Integer.parseInt(line[4]));
                        pet.setFullness(Integer.parseInt(line[5]));
                        pet.setHappiness(Integer.parseInt(line[6]));
                        break;
                    case "Item":
                        inventory.addItem(new InventoryItem(line[1], Integer.parseInt(line[2]), "type", Integer.parseInt(line[3])));
                        break;
                    case "Score":
                        score = Integer.parseInt(line[1]);
                        break;
                }
            }
            return new GameState(pet, inventory, parentalControls, score, slotIndex);
        } catch (IOException e) {
            System.err.println("Failed to load game state: " + e.getMessage());
            return null;
        }
    }
    /**
     * This method is for getting the parental controls.
     * 
     * @return parentalControls
     */
    public ParentalControls getParentalControls() {
        return this.parentalControls; // Ensure parentalControls is a member variable
    }
    
    /**
     * This method is checking if the current time is within the allowed time range 
     * 
     * @return boolean
     */
    public boolean isWithinAllowedTime() {
        LocalTime current = LocalTime.now();
        return current.isAfter(startAllowedTime) && current.isBefore(endAllowedTime);
    }

    /**
     * This method is for enforcing the playtime restrictions set.
     */
    public void enforcePlaytimeRestrictions() {
        if (!isWithinAllowedTime()) {
            JOptionPane.showMessageDialog(null, "Playtime is restricted during this time!");
            System.exit(0);
        }
    }

    /**
     * This method is for setting the playtime limits.
     * 
     * @param startTime
     * @param endTime
     */
    public void setPlaytimeLimits(String startTime, String endTime) {
            this.startAllowedTime = LocalTime.parse(startTime); // Parse string to LocalTime
            this.endAllowedTime = LocalTime.parse(endTime);
        }
}

/*case "ParentalControls":
                    parentalControls.setTotalPlayTime(Integer.parseInt(line[1]));
                    parentalControls.setTimeRestriction(Boolean.parseBoolean(line[2]),
                            Integer.parseInt(line[3]), Integer.parseInt(line[4]));
                    break;*/