package model;

import javafx.application.Platform;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class MusicPlayer {
    private MediaPlayer mediaPlayer;
    private final List<String> songs = new ArrayList<>();
    private final Queue<Integer> recentHistory = new LinkedList<>();
    private final int historySize = 2; // Avoid immediate repeats
    private int currentSongIndex; // Add this field to store the current song index


    public MusicPlayer() {
        ensureJavaFXInitialized();

        // Add your songs from the Songs folder
        songs.add("/Songs/TDFTI.mp3");
        songs.add("/Songs/hearty.mp3");
        songs.add("/Songs/hope.mp3");
        songs.add("/Songs/laststop.mp3");
    }

    /**
     * Ensures the JavaFX toolkit is initialized only once.
     */
    private void ensureJavaFXInitialized() {
        if (!Platform.isFxApplicationThread() && !ToolkitInitialized.INSTANCE.isInitialized()) {
            Platform.startup(() -> {});
            ToolkitInitialized.INSTANCE.setInitialized(true);
        }
    }

    public void playRandomSong(Integer previous) {
        try {
            do {
                currentSongIndex = new Random().nextInt(songs.size());
            } while (recentHistory.contains(currentSongIndex));

            if (recentHistory.size() >= historySize) {
                recentHistory.poll(); // Remove the oldest song from the history
            }
            recentHistory.add(currentSongIndex);

            System.out.println("Now playing: " + songs.get(currentSongIndex));

            String songPath = getClass().getResource(songs.get(currentSongIndex)).toExternalForm();
            Media media = new Media(songPath);
            MediaPlayer nextPlayer = new MediaPlayer(media);

            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.dispose();
            }

            mediaPlayer = nextPlayer;
            mediaPlayer.setOnEndOfMedia(() -> playRandomSong(currentSongIndex)); // Use the field
            mediaPlayer.play();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopMusic() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.dispose();
            mediaPlayer = null;
            System.out.println("Music stopped and resources released.");
        }
    }
}

/**
 * Singleton to track JavaFX toolkit initialization state.
 */
enum ToolkitInitialized {
    INSTANCE;

    private boolean initialized = false;

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
}
