package MainRoomUnitTest;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import javax.swing.*;

public class LoginPageParentsTest {
    
    private login_page_parents loginPage;
    private ParentalControls mockParentalControls;
    
    @BeforeEach
    public void setUp() {
        // Initialize the mock object and the login page
        mockParentalControls = mock(ParentalControls.class);
        loginPage = new login_page_parents();
        
        // Inject the mock into the login page
        loginPage.setParentalControls(mockParentalControls);
    }

    @Test
    public void testLogin_Successful() {
        // Arrange: Mock the login validation to return true
        when(mockParentalControls.validateLogin("parent", "password123")).thenReturn(true);
        
        // Set username and password fields
        loginPage.jTextField1.setText("parent");
        loginPage.jTextField2.setText("password123");
        
        // Act: Trigger the login button click
        loginPage.login.doClick();
        
        // Assert: Check that the login was successful and the settings page is shown
        verify(mockParentalControls).validateLogin("parent", "password123");
        JOptionPane.showMessageDialog(loginPage, "Login successful!");
    }
    
    @Test
    public void testLogin_Failed() {
        // Arrange: Mock the login validation to return false
        when(mockParentalControls.validateLogin("parent", "wrongpassword")).thenReturn(false);
        
        // Set username and password fields
        loginPage.jTextField1.setText("parent");
        loginPage.jTextField2.setText("wrongpassword");
        
        // Act: Trigger the login button click
        loginPage.login.doClick();
        
        // Assert: Verify that the error message is shown
        verify(mockParentalControls).validateLogin("parent", "wrongpassword");
        JOptionPane.showMessageDialog(loginPage, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    @Test
    public void testBackButton() {
        // Act: Simulate the back button click
        loginPage.jButton2.doClick();
        
        // Assert: Verify that the MainMenu screen is opened
        // In this case, you can mock the MainMenu constructor or verify the method call.
        verify(loginPage, times(1)).dispose();
    }
}
